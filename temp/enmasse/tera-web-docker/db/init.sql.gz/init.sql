-- MySQL dump 10.13  Distrib 5.5.54, for debian-linux-gnu (x86_64)
--
-- Host: db    Database: site_development
-- ------------------------------------------------------
-- Server version	5.6.34-79.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `refinery_authentication_devise_roles`
--

DROP TABLE IF EXISTS `refinery_authentication_devise_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `refinery_authentication_devise_roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `refinery_authentication_devise_roles`
--

LOCK TABLES `refinery_authentication_devise_roles` WRITE;
/*!40000 ALTER TABLE `refinery_authentication_devise_roles` DISABLE KEYS */;
INSERT INTO `refinery_authentication_devise_roles` VALUES (1,'Refinery'),(2,'Superuser');
/*!40000 ALTER TABLE `refinery_authentication_devise_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `refinery_authentication_devise_roles_users`
--

DROP TABLE IF EXISTS `refinery_authentication_devise_roles_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `refinery_authentication_devise_roles_users` (
  `user_id` int(11) DEFAULT NULL,
  `role_id` int(11) DEFAULT NULL,
  KEY `refinery_roles_users_role_id_user_id` (`role_id`,`user_id`),
  KEY `refinery_roles_users_user_id_role_id` (`user_id`,`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `refinery_authentication_devise_roles_users`
--

LOCK TABLES `refinery_authentication_devise_roles_users` WRITE;
/*!40000 ALTER TABLE `refinery_authentication_devise_roles_users` DISABLE KEYS */;
INSERT INTO `refinery_authentication_devise_roles_users` VALUES (1,1),(1,2);
/*!40000 ALTER TABLE `refinery_authentication_devise_roles_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `refinery_authentication_devise_user_plugins`
--

DROP TABLE IF EXISTS `refinery_authentication_devise_user_plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `refinery_authentication_devise_user_plugins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `position` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `refinery_user_plugins_user_id_name` (`user_id`,`name`),
  KEY `index_refinery_authentication_devise_user_plugins_on_name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `refinery_authentication_devise_user_plugins`
--

LOCK TABLES `refinery_authentication_devise_user_plugins` WRITE;
/*!40000 ALTER TABLE `refinery_authentication_devise_user_plugins` DISABLE KEYS */;
INSERT INTO `refinery_authentication_devise_user_plugins` VALUES (1,1,'refinery_authentication_devise',1),(2,1,'refinery_pages',2),(3,1,'refinery_files',3),(4,1,'refinery_images',4);
/*!40000 ALTER TABLE `refinery_authentication_devise_user_plugins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `refinery_authentication_devise_users`
--

DROP TABLE IF EXISTS `refinery_authentication_devise_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `refinery_authentication_devise_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `encrypted_password` varchar(255) NOT NULL,
  `current_sign_in_at` datetime DEFAULT NULL,
  `last_sign_in_at` datetime DEFAULT NULL,
  `current_sign_in_ip` varchar(255) DEFAULT NULL,
  `last_sign_in_ip` varchar(255) DEFAULT NULL,
  `sign_in_count` int(11) DEFAULT NULL,
  `remember_created_at` datetime DEFAULT NULL,
  `reset_password_token` varchar(255) DEFAULT NULL,
  `reset_password_sent_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `full_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_refinery_authentication_devise_users_on_id` (`id`),
  KEY `index_refinery_authentication_devise_users_on_slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `refinery_authentication_devise_users`
--

LOCK TABLES `refinery_authentication_devise_users` WRITE;
/*!40000 ALTER TABLE `refinery_authentication_devise_users` DISABLE KEYS */;
INSERT INTO `refinery_authentication_devise_users` VALUES (1,'eme_refinery_admin','platform@enmasse.com','$2a$10$3Pfm45Q/EU7W0hDVZfXB7uS1zRfYQLSfQXFs6i8XcPb6eZACyU9LW','2017-04-25 16:23:45','2017-04-24 16:49:42','172.18.0.1','172.18.0.1',3,NULL,NULL,NULL,'2017-01-05 20:38:36','2017-04-25 16:23:45','eme_refinery_admin',NULL);
/*!40000 ALTER TABLE `refinery_authentication_devise_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `refinery_blog_categories`
--

DROP TABLE IF EXISTS `refinery_blog_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `refinery_blog_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_refinery_blog_categories_on_id` (`id`),
  KEY `index_refinery_blog_categories_on_slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `refinery_blog_categories`
--

LOCK TABLES `refinery_blog_categories` WRITE;
/*!40000 ALTER TABLE `refinery_blog_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `refinery_blog_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `refinery_blog_categories_blog_posts`
--

DROP TABLE IF EXISTS `refinery_blog_categories_blog_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `refinery_blog_categories_blog_posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `blog_category_id` int(11) DEFAULT NULL,
  `blog_post_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_blog_categories_blog_posts_on_bc_and_bp` (`blog_category_id`,`blog_post_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `refinery_blog_categories_blog_posts`
--

LOCK TABLES `refinery_blog_categories_blog_posts` WRITE;
/*!40000 ALTER TABLE `refinery_blog_categories_blog_posts` DISABLE KEYS */;
/*!40000 ALTER TABLE `refinery_blog_categories_blog_posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `refinery_blog_category_translations`
--

DROP TABLE IF EXISTS `refinery_blog_category_translations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `refinery_blog_category_translations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `refinery_blog_category_id` int(11) NOT NULL,
  `locale` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_a0315945e6213bbe0610724da0ee2de681b77c31` (`refinery_blog_category_id`),
  KEY `index_refinery_blog_category_translations_on_locale` (`locale`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `refinery_blog_category_translations`
--

LOCK TABLES `refinery_blog_category_translations` WRITE;
/*!40000 ALTER TABLE `refinery_blog_category_translations` DISABLE KEYS */;
/*!40000 ALTER TABLE `refinery_blog_category_translations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `refinery_blog_comments`
--

DROP TABLE IF EXISTS `refinery_blog_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `refinery_blog_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `blog_post_id` int(11) DEFAULT NULL,
  `spam` tinyint(1) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `body` text,
  `state` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_refinery_blog_comments_on_id` (`id`),
  KEY `index_refinery_blog_comments_on_blog_post_id` (`blog_post_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `refinery_blog_comments`
--

LOCK TABLES `refinery_blog_comments` WRITE;
/*!40000 ALTER TABLE `refinery_blog_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `refinery_blog_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `refinery_blog_post_translations`
--

DROP TABLE IF EXISTS `refinery_blog_post_translations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `refinery_blog_post_translations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `refinery_blog_post_id` int(11) NOT NULL,
  `locale` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `body` text,
  `custom_teaser` text,
  `custom_url` varchar(255) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_refinery_blog_post_translations_on_refinery_blog_post_id` (`refinery_blog_post_id`),
  KEY `index_refinery_blog_post_translations_on_locale` (`locale`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `refinery_blog_post_translations`
--

LOCK TABLES `refinery_blog_post_translations` WRITE;
/*!40000 ALTER TABLE `refinery_blog_post_translations` DISABLE KEYS */;
INSERT INTO `refinery_blog_post_translations` VALUES (1,1,'en','2017-04-19 18:07:11','2017-04-24 19:49:15','<p>Prior to negotiating you should establish criteria by asking enough questions to uncover the primary objectives and goals of the buyer and seller.</p>\r\n<h3>1. Nibbling</h3>\r\n<p>A strategy that buyers use to obtain the majority of what they are asking for by making the seller feel cheap. As the name explains, the buyer nibbles a bite here and a bite there — slowly getting everything they desire from the seller.</p>\r\n<div class=\"text-align-center margin1\">\r\n<a href=\"/assets/bgs/test-post-img.jpg\"><img class=\"double-border\" src=\"/assets/bgs/test-post-img.jpg\" style=\"margin:0\" title=\"Dancing Rogue\" alt=\"Dancing Rogue\" /></a>\r\n</div>','<p>Prior to negotiating you should establish criteria by asking enough questions to uncover the primary objectives and goals of the buyer and seller.\r\n</p>','','test-post-one','Test Post One'),(2,2,'en','2017-04-24 19:31:20','2017-04-24 19:31:20','<p>body copy about post two</p>','','','test-post-two','Test Post Two');
/*!40000 ALTER TABLE `refinery_blog_post_translations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `refinery_blog_posts`
--

DROP TABLE IF EXISTS `refinery_blog_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `refinery_blog_posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `body` text,
  `draft` tinyint(1) DEFAULT NULL,
  `published_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `custom_url` varchar(255) DEFAULT NULL,
  `custom_teaser` text,
  `source_url` varchar(255) DEFAULT NULL,
  `source_url_title` varchar(255) DEFAULT NULL,
  `access_count` int(11) DEFAULT '0',
  `slug` varchar(255) DEFAULT NULL,
  `teaser_image_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_refinery_blog_posts_on_id` (`id`),
  KEY `index_refinery_blog_posts_on_access_count` (`access_count`),
  KEY `index_refinery_blog_posts_on_slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `refinery_blog_posts`
--

LOCK TABLES `refinery_blog_posts` WRITE;
/*!40000 ALTER TABLE `refinery_blog_posts` DISABLE KEYS */;
INSERT INTO `refinery_blog_posts` VALUES (1,NULL,NULL,0,'2017-04-19 18:06:00','2017-04-19 18:07:11','2017-04-24 19:49:28',1,NULL,NULL,'','',14,NULL,1),(2,NULL,NULL,0,'2017-04-24 19:30:00','2017-04-24 19:31:20','2017-04-24 19:51:29',1,NULL,NULL,'','',3,NULL,NULL);
/*!40000 ALTER TABLE `refinery_blog_posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `refinery_image_translations`
--

DROP TABLE IF EXISTS `refinery_image_translations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `refinery_image_translations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `refinery_image_id` int(11) NOT NULL,
  `locale` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `image_alt` varchar(255) DEFAULT NULL,
  `image_title` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_refinery_image_translations_on_refinery_image_id` (`refinery_image_id`),
  KEY `index_refinery_image_translations_on_locale` (`locale`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `refinery_image_translations`
--

LOCK TABLES `refinery_image_translations` WRITE;
/*!40000 ALTER TABLE `refinery_image_translations` DISABLE KEYS */;
INSERT INTO `refinery_image_translations` VALUES (1,1,'en','2017-04-19 18:07:43','2017-04-19 18:07:43','','Logo');
/*!40000 ALTER TABLE `refinery_image_translations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `refinery_images`
--

DROP TABLE IF EXISTS `refinery_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `refinery_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `image_mime_type` varchar(255) DEFAULT NULL,
  `image_name` varchar(255) DEFAULT NULL,
  `image_size` int(11) DEFAULT NULL,
  `image_width` int(11) DEFAULT NULL,
  `image_height` int(11) DEFAULT NULL,
  `image_uid` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `image_title` varchar(255) DEFAULT NULL,
  `image_alt` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `refinery_images`
--

LOCK TABLES `refinery_images` WRITE;
/*!40000 ALTER TABLE `refinery_images` DISABLE KEYS */;
INSERT INTO `refinery_images` VALUES (1,NULL,'logo.png',154988,637,281,'2017/04/19/8tm0l8vyy5_logo.png','2017-04-19 18:07:43','2017-04-19 18:07:43',NULL,NULL);
/*!40000 ALTER TABLE `refinery_images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `refinery_page_part_translations`
--

DROP TABLE IF EXISTS `refinery_page_part_translations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `refinery_page_part_translations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `refinery_page_part_id` int(11) NOT NULL,
  `locale` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `body` text,
  PRIMARY KEY (`id`),
  KEY `index_refinery_page_part_translations_on_refinery_page_part_id` (`refinery_page_part_id`),
  KEY `index_refinery_page_part_translations_on_locale` (`locale`)
) ENGINE=InnoDB AUTO_INCREMENT=86 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `refinery_page_part_translations`
--

LOCK TABLES `refinery_page_part_translations` WRITE;
/*!40000 ALTER TABLE `refinery_page_part_translations` DISABLE KEYS */;
INSERT INTO `refinery_page_part_translations` VALUES (1,1,'en','2017-04-18 21:52:40','2017-04-18 21:52:40','<p>Welcome to our site. This is just a place holder page while we gather our content.</p>'),(2,2,'en','2017-04-18 21:52:40','2017-04-18 21:52:40','<p>This is another block of content over here.</p>'),(3,3,'en','2017-04-18 21:52:41','2017-04-18 21:52:41','<h2>Sorry, there was a problem...</h2><p>The page you requested was not found.</p><p><a href=\"/\">Return to the home page</a></p>'),(6,6,'en','2017-04-18 21:52:43','2017-04-18 21:53:56',''),(7,7,'en','2017-04-18 21:52:43','2017-04-18 21:53:56',''),(8,8,'en','2017-04-18 21:52:44','2017-04-18 21:53:56',''),(9,9,'en','2017-04-18 21:52:44','2017-04-18 21:53:56',''),(10,10,'en','2017-04-18 21:52:45','2017-04-18 21:53:56',''),(11,11,'en','2017-04-21 19:50:29','2017-04-24 21:54:00','<h1>What You Need to Know…</h1>'),(12,12,'en','2017-04-21 19:50:29','2017-04-25 16:31:34','<p>Move with the familiar W A S D keys, and inflict damage with the surrounding keys and your mouse.</p>\r\n<h3>COMBAT</h3>\r\n<p><strong>There Are NO Roles</strong>\r\n</p>\r\n<p>This is a fighting game. Kritika doesn\'t have tanks, healers, and DPS classes. It has hitters—period.</p>\r\n<p><strong>Do It from Behind</strong>\r\n</p>\r\n<p>Sure, you can wade in and pound your enemy face to face, but back attacks make a big difference. If a fight is too difficult, try repositioning your attacks.</p>\r\n<p><strong>Stay Alive</strong>\r\n</p>\r\n<p>Kritika doesn\'t have healers, so you need to move, dash, and jump to evade attacks. If you\'re not fast enough, wolf down some food for HP and guzzle some drinks for MP.</p>\r\n<h3>CLASSES</h3>\r\n<p>All classes in Kritika deal massive amounts of damage, but there are several options to suit your play style.</p>\r\n<p><strong><a href=\"/guides/classes/warrior\">Warrior</a>\r\n</strong>\r\n</p>\r\n<p>He\'s a sword-wielding fighter focused on pounding down opponents in melee.</p>\r\n<p>Warrior specialties: Berserker, Fire Lord, Doom Blade</p>\r\n<p><strong><a href=\"/guides/classes/rogue\">Rogue</a>\r\n</strong>\r\n</p>\r\n<p>She\'s a dagger-wielding animal-loving acrobat who dances in and out of danger\'s way.</p>\r\n<p>Rogue specialties: Assassin, Catspaw, Wolf Guardian</p>\r\n<p><strong><a href=\"/guides/classes/gunmage\">Gunmage</a>\r\n</strong>\r\n</p>\r\n<p>He\'s a gun-toting master of the elemental arts who prefers to blast enemies at range than soil his pretty hands.</p>\r\n<p>Gunmage specialties: Frost Mage, Shadow Mage, Warp Mage</p>\r\n<p><strong><a href=\"/guides/classes/reaper\">Reaper</a>\r\n</strong>\r\n</p>\r\n\r\n<p>She\'s a scythe-wielding Mata Hari whose expertise with chains or blood make her dangerous at close- or mid-range.</p>\r\n<p>Reaper specialties: Valkyrie, Vamp</p>\r\n<h3>GAME PLAY</h3>\r\n<p><strong>Danger Zones</strong>\r\n</p>\r\n<p>Complete quests, battle monsters, and more by accessing the Danger Zone portal from any town. Danger zones in Kritika only take a few minutes to complete. Fights are furious and fast, which means you can move on to the next adventure without hours of down-time.</p>\r\n<p>Danger Zones usually have four difficulties: Normal, Hard, Insane, and OMFG. No matter which, each Danger Zone finishes with a big boss battle. The harder the Danger Zone the bigger your rewards in gold and EXP.</p>\r\n<p><strong>PvP</strong>\r\n</p>\r\n<p>Once you\'re level 15, you can access the player-vs-player interface by pressing [P].  Fight one-on-one or team up for 3v3 battles or capture the flag fun. Ranked matches will determine your season\'s ranking and rewards.</p>\r\n<p><strong>Arena</strong>\r\n</p>\r\n<p>At level 60, take your fights to the next level in Scar\'s Arena. Test your stamina and process with ten one-on-one duels with NPCs, and win special rewards.</p>\r\n<h3>GOODIES</h3>\r\n<p><strong>Enhancement? ENHANCEMENT!</strong>\r\n</p>\r\n<p>There are many ways to improve your character\'s skills and equipment. Enchantment, enhancement, refining, gemstones, and many more! Always be improving! </p>\r\n<p><strong>Little Things Matter</strong>\r\n</p>\r\n<p>Everything from costumes to titles to pets improves your stats and your ability to fight!</p>'),(13,13,'en','2017-04-21 19:50:29','2017-04-21 19:50:29',''),(14,14,'en','2017-04-21 19:50:29','2017-04-21 19:50:29',''),(15,15,'en','2017-04-21 19:50:29','2017-04-21 19:50:29',''),(16,16,'en','2017-04-21 19:52:42','2017-04-24 20:20:28','<h1>Game Guide: <span>The Warrior</span>\r\n</h1>'),(17,17,'en','2017-04-21 19:52:42','2017-04-25 16:26:02','<button type=\"button\" class=\"trailer\" id=\"trailerWarrior\" style=\"height: 584px; width: 892px; background-image: url(/assets/video/warrior-video-thumb.jpg)\" data-url=\"https://www.youtube.com/embed/GwoFsacU4As\"></button>\r\n<p>The warrior is a sword-wielding close-combat fighter. Bold, tough, and strong, the warrior is a front-line powerhouse who can dispatch enemies with ease. Their massive swords deal a tremendous amount of damage, making short work of even boss monsters. Warriors wear heavy armor.</p>\r\n\r\n<h3>Basic Skills</h3>\r\n\r\n<p>The warrior\'s starting skills are drawn from the warrior\'s specialty classes. When you choose a specialty at level 15, you\'ll get the chance to re-focus and phase out the skills from the other two specialties.</p>\r\n\r\n<h3>The Berserker</h3>\r\n\r\n<p>Berserkers channel their inner rage into wild, spectacular onslaughts.</p>\r\n\r\n<table>\r\n    <tbody><tr><th>Attack</th>\r\n<th>The Kritikal Impact</th>\r\n</tr>\r\n    <tr><td>Double Slash</td>\r\n<td>Make two quick slashing attacks.</td>\r\n</tr>\r\n    <tr><td>Lunge</td>\r\n<td>Rush forward and impale your target.</td>\r\n</tr>\r\n    <tr><td>Whirlwind Slash</td>\r\n<td>Launch a series of spinning attacks as you whirl toward your enemies.</td>\r\n</tr>\r\n    <tr><td>Swing for the Fences</td>\r\n<td>Knock your target into the air, then hit ‘em again to send ‘em flying!</td>\r\n</tr>\r\n    <tr><td>Furious Charge</td>\r\n<td>Rush forward like a lunge, but hit the skill button up to twice more for more attacks.</td>\r\n</tr>\r\n    <tr><td>Buzzsaw</td>\r\n<td>Launch a spinning overhead strike to cut through enemies like, well, a buzzsaw.</td>\r\n</tr>\r\n    <tr><td>Chaos</td>\r\n<td>Hit the skill button twice in quick succession to unleash a devastating flurry of sword blows.</td>\r\n</tr>\r\n    <tr><td>Roundup Assault</td>\r\n<td>Assault your enemies with a series of blows, knocking them back a little with each hit.</td>\r\n</tr>\r\n    <tr><td>Brutal Chop</td>\r\n<td>Gather your anger, then hold the skill button to land a torrent of rage on your foe.</td>\r\n</tr>\r\n    <tr><td>Berserk Frenzy</td>\r\n<td>Hit the skill button, then rapidly tap the left mouse while charging your enemies. </td>\r\n</tr>\r\n    <tr><td>Intimidating Roar</td>\r\n<td>Replenish your stamina and fury and get back in the fight! It\'s also a great zero-range area attack.</td>\r\n</tr>\r\n    <tr><td>Battle Leap</td>\r\n<td>Select a spot within range, then leap to it and land like an exploding bomb of fury.</td>\r\n</tr>\r\n    <tr><td>Swordnado</td>\r\n<td>Launch into a whirlwind spin, slashing through foes in a 360-degree arc around you.</td>\r\n</tr>\r\n    <tr><td>Second Wind</td>\r\n<td>Sacrifice some of your MP to increase your maximum Stamina.</td>\r\n</tr>\r\n    <tr><td>Onslaught</td>\r\n<td>Hold down the skill button to build up your fury, then tap the left mouse button to channel that into your sword for a massive, sweeping attack.</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n\r\n<h3>The Fire Lord</h3>\r\n\r\n<p>Fire lords utilize a special metal gauntlet that lets them draw on flame energy to boost the power of their attacks. A fire lord is somewhat more difficult to play than other warrior specialty classes because they lack the faster attacks, focusing instead on building up their firepower with combos.</p>\r\n\r\n<table>\r\n    <tbody><tr><th>Attack</th>\r\n<th>The Kritikal Impact</th>\r\n</tr>\r\n    <tr><td>Lava Wave</td>\r\n<td>Slam the ground, knocking the target into the air...and setting the target on fire.</td>\r\n</tr>\r\n    <tr><td>Fiery Smite</td>\r\n<td>Leap toward an opponent and slam the ground, sparking an explosion.</td>\r\n</tr>\r\n    <tr><td>Cannon Fist</td>\r\n<td>Wind up and throw a fiery haymaker.</td>\r\n</tr>\r\n    <tr><td>Fiery Tantrum</td>\r\n<td>Grab a target and drag it all over the place, on fire.</td>\r\n</tr>\r\n    <tr><td>Boom Punch</td>\r\n<td>Wind up and throw a fiery uppercut, knocking opponents into the air.</td>\r\n</tr>\r\n    <tr><td>Meteor Fist</td>\r\n<td>Leap up into the air and slam back down, knocking your opponents off their feet.</td>\r\n</tr>\r\n    <tr><td>Fire Shield</td>\r\n<td>Hold down the button to gather fiery power, then plow forward in a blaze of glory.</td>\r\n</tr>\r\n    <tr><td>Volcano</td>\r\n<td>Knock an opponent into the air, then hold down the button to generate a volcanic eruption.</td>\r\n</tr>\r\n    <tr><td>Fire Slam</td>\r\n<td>Rush an opponent and haul them up into the air for a brutal, fiery slam-down.</td>\r\n</tr>\r\n    <tr><td>Detonate</td>\r\n<td>Hit the button, then attack an opponent multiple times while increasing your Defense Power.</td>\r\n</tr>\r\n    <tr><td>Empower</td>\r\n<td>Click the left and right mouse buttons to increase your Attack Power. </td>\r\n</tr>\r\n    <tr><td>Hellfire Hot Tub</td>\r\n<td>Hold the button to generate an intensely hot pool of molten magma, boiling enemies alive.</td>\r\n</tr>\r\n    <tr><td>Blaze of Glory</td>\r\n<td>Charge up your gauntlet with explosive energy, then use the left mouse button to fire the energy like a cannon.</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n\r\n<h3>The Doom Blade</h3>\r\n\r\n<p>Doom Blades harness the curse of their diabolic katanas to cut through the souls of their opponents. They also have better ranged attacks than other warrior specialties.</p>\r\n\r\n<table>\r\n    <tbody><tr><th>Attack</th>\r\n<th>The Kritikal Impact</th>\r\n</tr>\r\n    <tr><td>Dark Slash</td>\r\n<td>Slice through opponents standing in front of you in a wide arc.</td>\r\n</tr>\r\n    <tr><td>Deadly Draw</td>\r\n<td>Slash twice at opponents in a wide arc in front of you, paralyzing the ones who don\'t immediately perish.</td>\r\n</tr>\r\n    <tr><td>Curse Drinker</td>\r\n<td>A vital skill; it loads up your curse meter so you can use certain key skills.</td>\r\n</tr>\r\n    <tr><td>Triple Lunge</td>\r\n<td>Expend curses to rip through the enemies\' ranks.</td>\r\n</tr>\r\n    <tr><td>Dancing Shadows</td>\r\n<td>Hit the button multiple times to deliver multiple slashing blows.</td>\r\n</tr>\r\n    <tr><td>Oblivion</td>\r\n<td>Unleash a torrent of soul-destroying energy against multiple targets.</td>\r\n</tr>\r\n    <tr><td>Purgatory Wave</td>\r\n<td>Hold the skill button to build up a wide wave of energy, then hurl it out at distant foes.</td>\r\n</tr>\r\n    <tr><td>Soul Vortex</td>\r\n<td>Strike a foe to generate a soul-sucking singularity.</td>\r\n</tr>\r\n    <tr><td>Soulsteal</td>\r\n<td>Hold the skill button to pull foes in, then deliver a vicious chopping blow.</td>\r\n</tr>\r\n    <tr><td>Spectral Assault</td>\r\n<td>Slash, then lunge forward for another slash, or hold the skill button to go straight to the lunge.</td>\r\n</tr>\r\n    <tr><td>Spirit Barrage</td>\r\n<td>Deliver a series of spectral blows at close range.</td>\r\n</tr>\r\n    <tr><td>Six-Blade Leap</td>\r\n<td>Leap into the air and slash down on your foe.</td>\r\n</tr>\r\n    <tr><td>Ghost Blast</td>\r\n<td>Hit the skill button once to drain the souls from your enemies, then again to unleash that energy as a wide, slashing attack.</td>\r\n</tr>\r\n    <tr><td>Shadow Stride</td>\r\n<td>Hold the skill button to build up power, then dash forward, slashing through your enemy.</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n\r\n<h3>Skill Modifiers: EX and Awakened</h3>\r\n<div>\r\n<img class=\"left-image\" src=\"/assets/warrior-placeholder.jpg\" />\r\n\r\n<p>EX skills cast enhanced versions of your skills, but rely on EX energy to use. When your EX bar is full, press Tab to activate EX mode, then choose the skill you want to use. EX energy drains quickly, though, so make your choice fast.</p>\r\n\r\n<p>Awakened skills provide boosts and tweaks to your skills. You\'ll only have a limited number of points to spend on these, though, so improve the ones you use most.</p>\r\n</div>'),(18,18,'en','2017-04-21 19:52:42','2017-04-21 19:52:42',''),(19,19,'en','2017-04-21 19:52:42','2017-04-21 19:52:42',''),(20,20,'en','2017-04-21 19:52:42','2017-04-21 19:52:42',''),(21,21,'en','2017-04-21 20:59:50','2017-04-21 20:59:50',''),(22,22,'en','2017-04-21 20:59:50','2017-04-21 20:59:50',''),(23,23,'en','2017-04-21 20:59:50','2017-04-21 20:59:50',''),(24,24,'en','2017-04-21 20:59:51','2017-04-21 20:59:51',''),(25,25,'en','2017-04-21 20:59:51','2017-04-21 20:59:51',''),(26,26,'en','2017-04-21 21:20:33','2017-04-24 21:40:27','<h1>GAME GUIDE: <span>THE ROGUE</span>\r\n</h1>'),(27,27,'en','2017-04-21 21:20:33','2017-04-25 16:26:32','<button type=\"button\" class=\"trailer\" id=\"trailerWarrior\" style=\"height: 584px; width: 892px; background-image: url(/assets/video/warrior-video-thumb.jpg)\" data-url=\"https://www.youtube.com/embed/GwoFsacU4As\"></button>\r\n<p>The rogue is a dagger-wielding acrobat. She moves fast and hits hard—slicing, scratching, or shocking her opponents. Always the opportunists, they excel at back attacks, misdirection, and outright elemental destruction. Rogues have an affinity for animals and wear medium armor.</p>\r\n\r\n<h3>Basic Skills</h3>\r\n\r\n<p>The rogue\'s starting skills are designed for quick, effective damage. You\'ll focus on taking out one target at a time, with kicks, punches, slashes, and lightning attacks! At level 15 you\'ll be able to fine tune your skills into one of three specialties:</p>\r\n\r\n<h3>Catspaw</h3>\r\n\r\n<p>Wielding blades like claws, the catspaw lives to kill and subdue her enemies with fast-firing skill chains and aerial attacks.</p>\r\n\r\n<table>\r\n    <tbody><tr><th>Attack</th>\r\n<th>The Kritikal Impact</th>\r\n</tr>\r\n    <tr><td>Cat\'s Kick</td>\r\n<td>Backflip and kick your enemy into the air.</td>\r\n</tr>\r\n    <tr><td>Claw Slash</td>\r\n<td>Damage an enemy in front of you, and keep the hits coming!</td>\r\n</tr>\r\n    <tr><td>Cat Slam</td>\r\n<td>Plow through enemies, gathering them up for a massive back attack.</td>\r\n</tr>\r\n    <tr><td>Spiral Kill</td>\r\n<td>Spin into your enemies, damaging everything in your path.</td>\r\n</tr>\r\n    <tr><td>Deathclaw</td>\r\n<td>Perform four rapid-fire claw swipes and a roundpaw kick.</td>\r\n</tr>\r\n    <tr><td>Cat-a-Pult</td>\r\n<td>Toss your enemies into the air with a powerful claw strike.</td>\r\n</tr>\r\n    <tr><td>Tailchaser</td>\r\n<td>Spin your enemies in a dizzying, defense-reducing whirlwind.</td>\r\n</tr>\r\n    <tr><td>Lightning Cat</td>\r\n<td>Leap up and strike a foe like a bolt of lightning.</td>\r\n</tr>\r\n    <tr><td>Furball</td>\r\n<td>Transform into a spinning ball of invulnerable energy and attack all nearby enemies.</td>\r\n</tr>\r\n    <tr><td>Cat-Astrophe</td>\r\n<td>Gain frenzy and invulnerability, attacking all nearby enemies.</td>\r\n</tr>\r\n    <tr><td>Furry Fury</td>\r\n<td>Summons a band of ferocious attack kittens. </td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n\r\n<h3>Assassin</h3>\r\n\r\n<p>The ultimate 1v1 opponent, the assassin moves fast and kills faster, often disappearing before her foe hits the ground</p>\r\n\r\n<table>\r\n    <tbody><tr><th>Attack</th>\r\n<th>The Kritikal Impact</th>\r\n</tr>\r\n    <tr><td>Quick Jab</td>\r\n<td>Teleport to and enemy and give them a serious wound.</td>\r\n</tr>\r\n    <tr><td>Triple Kill</td>\r\n<td>Attack three times in rapid succession.</td>\r\n</tr>\r\n    <tr><td>Deathcloud</td>\r\n<td>Spray a deadly poison that reduces enemy stats and deals damage over time.</td>\r\n</tr>\r\n    <tr><td>Backslash</td>\r\n<td>Dash behind an enemy and attach with claw-shaped blades.</td>\r\n</tr>\r\n    <tr><td>Ghost Assassin</td>\r\n<td>Conceal yourself, gaining movement speed and an increased chance to crit.</td>\r\n</tr>\r\n    <tr><td>Skyblade</td>\r\n<td>Throw a giant shuriken and apply a bleeding effect to enemies.</td>\r\n</tr>\r\n    <tr><td>Fireblast</td>\r\n<td>Place a devastating bomb to leave enemies knocked down, stunned, and bleeding.</td>\r\n</tr>\r\n    <tr><td>Stormblade</td>\r\n<td>Throw a steady stream of shuriken in whatever direction you choose.</td>\r\n</tr>\r\n    <tr><td>Deathblast</td>\r\n<td>Unleash a poisonous cloud on your enemies.</td>\r\n</tr>\r\n    <tr><td>Cyclone Blade</td>\r\n<td>Throw a giant shuriken that pushes back enemies and makes them bleed.</td>\r\n</tr>\r\n    <tr><td>Shadow Charge</td>\r\n<td>Harass your enemies with multiple, blood-letting shuriken strikes. </td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n\r\n<h3>Wolf Guardian</h3>\r\n\r\n<p>Able to summon a powerful spirit wolf, the wolf guardian combines her own combat expertise and the powers of her otherworldly companion into devastating area-of-effect attacks.</p>\r\n\r\n<table>\r\n    <tbody><tr><th>Attack</th>\r\n<th>The Kritikal Impact</th>\r\n</tr>\r\n    <tr><td>Lightning Ball</td>\r\n<td>Attack an enemy with a powerful electric discharge.</td>\r\n</tr>\r\n    <tr><td>Shock</td>\r\n<td>Leap forward and damage all nearby enemies with a burst of lightning.</td>\r\n</tr>\r\n    <tr><td>Spirit Wolf</td>\r\n<td>Summon a powerful spirit ally to aid you in your fight.</td>\r\n</tr>\r\n    <tr><td>Flash</td>\r\n<td>Charge forward, attack, then dash away in a flash of light.</td>\r\n</tr>\r\n    <tr><td>Spirit Charge</td>\r\n<td>Command your spirit wolf to attack enemies in a line, and again on the return trip.</td>\r\n</tr>\r\n    <tr><td>Howl</td>\r\n<td>Your spirit wolf howls and calls lighting down around it while regaining HP.</td>\r\n</tr>\r\n    <tr><td>Electric Knives</td>\r\n<td>Throw electric blades that damage enemies, and charge them up for a lightning strike.</td>\r\n</tr>\r\n    <tr><td>Spirit Shock</td>\r\n<td>Teleport behind your spirit wolf\'s target and attack.</td>\r\n</tr>\r\n    <tr><td>Spirit Bite</td>\r\n<td>Your spirit wolf grabs an enemy, leaps into the air, then slams them into the ground.</td>\r\n</tr>\r\n    <tr><td>Thunder Spirit</td>\r\n<td>Increases movement speed and damage while enhancing the effects of lightning skills.</td>\r\n</tr>\r\n    <tr><td>Spirit Tornado</td>\r\n<td>Create and direct a lightning whirlwind, which reduces your foes\' movement speed.</td>\r\n</tr>\r\n    <tr><td>Spirit Rider</td>\r\n<td>Zip around the battlefield on your spirit wolf, immobilizing enemies with an electric field.</td>\r\n</tr>\r\n    <tr><td>One Million Volts</td>\r\n<td>Summon a circle of lightning damaging all enemies inside.</td>\r\n</tr>\r\n    <tr><td>Shared Spirit</td>\r\n<td>Your skills enhance your spirit wolf\'s power, and vice versa.</td>\r\n</tr>\r\n    <tr><td>Spirit Lightning Tango</td>\r\n<td>Transform your spirit wolf into a streak of lightning that gathers up enemies for a lightning strike.</td>\r\n</tr>\r\n    <tr><td>Ion Light Bullet</td>\r\n<td>Launch yourself at enemies while your spirit wolf bombards them with lightning strikes.</td>\r\n</tr>\r\n    <tr><td>Spirit Lightning Cascade</td>\r\n<td>Teleport your spirit wolf into a blast zone, where it electrocutes all enemies.</td>\r\n</tr>\r\n    <tr><td>Electric Field</td>\r\n<td>Absorb the power of your spirit wolf, and use it for a massive blast attack.</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n\r\n<h3>Skill Modifiers: EX and Awakened</h3>\r\n\r\n<img class=\"left-image\" src=\"/assets/warrior-placeholder.jpg\" />\r\n\r\n<p>EX skills cast enhanced versions of your skills, but rely on EX energy to use. When your EX bar is full, press Tab to activate EX mode, then choose the skill you want to use. EX energy drains quickly, though, so make your choice fast.</p>\r\n\r\n<p>Awakened skills provide boosts and tweaks to your skills. You\'ll only have a limited number of points to spend on these, though, so improve the ones you use most.</p>\r\n'),(28,28,'en','2017-04-21 21:20:33','2017-04-21 21:20:33',''),(29,29,'en','2017-04-21 21:20:33','2017-04-21 21:20:33',''),(30,30,'en','2017-04-21 21:20:33','2017-04-21 21:20:33',''),(31,31,'en','2017-04-21 23:37:18','2017-04-24 21:40:57','<h1>GAME GUIDE: <span>THE REAPER</span>\r\n</h1>'),(32,32,'en','2017-04-21 23:37:18','2017-04-25 16:27:55','<button type=\"button\" class=\"trailer\" id=\"trailerWarrior\" style=\"height: 584px; width: 892px; background-image: url(/assets/video/warrior-video-thumb.jpg)\" data-url=\"https://www.youtube.com/embed/GwoFsacU4As\"></button>\r\n<p>The reaper is a scythe-wielding Mata Hari sent from the alchemists of Perumagion. Sneaky, clever, and dangerous, the reaper is a close to mid-range damage-dealing class who can handle groups of enemies with ease. Reapers wear medium armor.</p>\r\n\r\n<h3>Basic Skills</h3>\r\n\r\n<p>The reaper starts off as a versatile melee attacker: basic attacks with your scythe strike a wide area, and you have a good amount of mobility and enemy control with Pirouette and Thorny Whip. When you specialize, your skills will reset, so feel free to pump points into them.</p>\r\n\r\n<h3>The Valkyrie</h3>\r\n\r\n<p>The valkyrie is perhaps the game\'s most versatile class. A simple right-click will switch you between Blade Stance—the valkyrie\'s fast-moving, hit-and-run combat style—and Chain Stance—its mid-range, battlefield-controlling counterpart. Switch often between the two stances: use Blade Stance to rush into a group of enemies, then once they\'re scattered, switch to Chain Stance to eliminate the stragglers with large area-of-effect attacks.</p>\r\n\r\n<table>\r\n    <tbody><tr><th>Attack</th>\r\n<th>The Kritikal Impact</th>\r\n</tr>\r\n    <tr><td>Reap</td>\r\n<td>One of the first skills you learn, and one you\'ll want to use a lot. In Blade Stance it delivers a solid melee, uppercut, and in Chain Stance it whips an enemy into the air at medium range.</td>\r\n</tr>\r\n    <tr><td>Pirouette</td>\r\n<td>In Blade Stance, you rush forward and gather up foes for a group beating. In Chain Stance, sweeps your chain scythe around in a wide area.</td>\r\n</tr>\r\n    <tr><td>Kama Strike</td>\r\n<td>Dashes forward to strike through an opponent in Blade Stance, or bashes them from afar in Chain Stance.</td>\r\n</tr>\r\n    <tr><td>Rakshasi</td>\r\n<td>As you use valkyrie skills, you\'ll build up energy you unleash in the form of Rakshasi, a massive area-of-effect sweep.</td>\r\n</tr>\r\n    <tr><td>Maelstrom Blade</td>\r\n<td>Throw your spinning scythe out to repeatedly cut enemies in front of you. Goes further in Chain Stance.</td>\r\n</tr>\r\n    <tr><td>Barbed Wrath*</td>\r\n<td>Delivers a nasty blow to one target (Blade Stance), or whips everything in a large area with spiked chains. (Chain Stance)</td>\r\n</tr>\r\n    <tr><td>Carousel of Carnage*</td>\r\n<td>Teleports around striking a single target (Blade Stance), or gathers up all enemies around you, swinging them around before slamming them to the ground (Chain Stance).</td>\r\n</tr>\r\n    <tr><td>Chain of Woe*</td>\r\n<td>Deals an incredible amount of damage to a single target (Blade Stance), or creates an exploding nest of chains at mid-range (Chain Stance).</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p>*Higher level skills</p>\r\n\r\n<h3>The Vamp</h3>\r\n\r\n<p>The vamp is a resilient fighter who uses blood magic to spread chaos and destruction. Not as fragile as the gunmage classes, the vamp isn\'t afraid to get up close and personal with her foes. The vamp never worries about running out of MP, either: the blood she drains from her foes keeps her going indefinitely. One of the first things you\'ll want to learn is which skills drain blood and which use it—this will allow you to manage your blood pool like a pro.</p>\r\n\r\n<table>\r\n    <tbody><tr><th>Attack</th>\r\n<th>The Kritikal Impact</th>\r\n</tr>\r\n    <tr><td>Sinister Pulse</td>\r\n<td>Your first blood draining ability, and a handy dash attack to boot. It cools down in 4 seconds, so use it frequently.</td>\r\n</tr>\r\n    <tr><td>Meat Hook</td>\r\n<td>Strikes enemies in a wide arc in front of you, drains their blood, and moves you out of harm\'s way.</td>\r\n</tr>\r\n    <tr><td>Blood Drive</td>\r\n<td>Awesome for refilling your blood pool in a pinch: this skill sucks the blood out of enemies all around you, and can be used even while moving or executing other skills.</td>\r\n</tr>\r\n    <tr><td>Red Tide</td>\r\n<td>Blows enemies away from you with an explosion of blood.</td>\r\n</tr>\r\n    <tr><td>Blood Rush</td>\r\n<td>Sends you flying forward, pushing enemies back with a shield of blood. Very satisfying to use.</td>\r\n</tr>\r\n    <tr><td>Arterial Burst</td>\r\n<td>Charge us a massive beam of blood and release it across the battlefield.</td>\r\n</tr>\r\n    <tr><td>Death of 1000 Bites</td>\r\n<td>Send out thousands of bats to toy with your enemies, draining blood for you as they do.</td>\r\n</tr>\r\n    <tr><td>Scythe Rift</td>\r\n<td>Deals an incredible amount of damage to a single target (Blade Stance), or creates an exploding nest of chains at mid-range (Chain Stance).</td>\r\n</tr>\r\n    <tr><td>Bloody Hell*</td>\r\n<td>Giant bloody spikes burst forth from the ground all around you, damaging and knocking up foes.</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p>*Higher level skills</p>\r\n\r\n<h3>Skill Modifiers: EX and Awakened</h3>\r\n\r\n<img class=\"left-image\" src=\"/assets/warrior-placeholder.jpg\" />\r\n\r\n<p>EX skills cast enhanced versions of your skills, but rely on EX energy to use. When your EX bar is full, press Tab to activate EX mode, then choose the skill you want to use. EX energy drains quickly, though, so make your choice fast.</p>\r\n\r\n<p>Awakened skills provide boosts and tweaks to your skills. You\'ll only have a limited number of points to spend on these, though, so improve the ones you use most.</p>'),(33,33,'en','2017-04-21 23:37:18','2017-04-21 23:37:18',''),(34,34,'en','2017-04-21 23:37:18','2017-04-21 23:37:18',''),(35,35,'en','2017-04-21 23:37:18','2017-04-21 23:37:18',''),(36,36,'en','2017-04-21 23:37:29','2017-04-24 21:41:24','<h1>GAME GUIDE: <span>THE GUNMAGE</span>\r\n</h1>'),(37,37,'en','2017-04-21 23:37:29','2017-04-25 16:28:36','<button type=\"button\" class=\"trailer\" id=\"trailerWarrior\" style=\"height: 584px; width: 892px; background-image: url(/assets/video/warrior-video-thumb.jpg)\" data-url=\"https://www.youtube.com/embed/GwoFsacU4As\"></button>\r\n<p>The gunmage is a gun-wielding wizard from the land of Xanadu. Cocky, clever, and powerful, the gunmage is a ranged damage-dealing class that can handle groups of enemies with ease. The handguns they carry let them focus their magical energies. Gunmages wear light armor.</p>\r\n\r\n<h3>Basic Skills</h3>\r\n\r\n<p>The gunmage\'s starting skills are drawn from all three specialty classes. When you choose a specialty at level 15, you\'ll get the chance to re-focus and phase out the skills from the other two specialties.</p>\r\n\r\n<h3>The Warp Mage</h3>\r\n\r\n<p>Warp mages manipulate time and space to keep opponents off balance. With the ability to slow time and control gravity, they can alter the flow of battle.</p>\r\n\r\n<table>\r\n    <tbody><tr><th>Attack</th>\r\n<th>The Kritikal Impact</th>\r\n</tr>\r\n    <tr><td>Teleport</td>\r\n<td>It\'s always handy to move around faster than your opponents can follow.</td>\r\n</tr>\r\n    <tr><td>Rock Dropper</td>\r\n<td>Triggers from time to time: Right-click to drop a rock on top of your enemies.</td>\r\n</tr>\r\n    <tr><td>Meteor Strike</td>\r\n<td>Like the Rock Dropper, but you choose when you want to drop the rock.</td>\r\n</tr>\r\n    <tr><td>Time Bomb</td>\r\n<td>Pick a target, and the clock starts counting down to the boom.</td>\r\n</tr>\r\n    <tr><td>Singularity</td>\r\n<td>Pulls enemies in and deals damages the whole time. Follow it up with Meteor Strike.</td>\r\n</tr>\r\n    <tr><td>Reverse Gravity</td>\r\n<td>Hurls enemies into the air and holds them there for a few seconds.</td>\r\n</tr>\r\n    <tr><td>Positron Beam</td>\r\n<td>Call down a beam of energy to deal devastating damage in a small area.</td>\r\n</tr>\r\n    <tr><td>Wall of Hurt</td>\r\n<td>Creates a shield in front of you that protects you while strengthening your skills.</td>\r\n</tr>\r\n    <tr><td>Wave Motion Gun</td>\r\n<td>Pulls up an aerial targeting grid. Pick your targets and call down a bombardment!</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n\r\n<h3>The Frost Mage</h3>\r\n\r\n<p>Frost mages fling ice and frost to dominate the battlefield—frequently by freezing their enemies in place. </p>\r\n\r\n<table>\r\n    <tbody><tr><th>Attack</th>\r\n<th>The Kritikal Impact</th>\r\n</tr>\r\n    <tr><td>Ice Needle</td>\r\n<td>Throws a shard of ice, which strikes all enemies in a line.</td>\r\n</tr>\r\n    <tr><td>Frost Blast</td>\r\n<td>A potent AOE skill that blasts targets in a broad, straight line. (Hold down the button to deal even more damage.)</td>\r\n</tr>\r\n    <tr><td>Hailstorm</td>\r\n<td>Choose an area, then shred it with a storm of razor-sharp ice.</td>\r\n</tr>\r\n    <tr><td>Ice Shards</td>\r\n<td>Throws spinning blades of ice to shred enemies. (Press the button twice for two blades.)</td>\r\n</tr>\r\n    <tr><td>Ice Lance</td>\r\n<td>Surround yourself with a field of razor-sharp ice.</td>\r\n</tr>\r\n    <tr><td>Chilblains</td>\r\n<td>Surround yourself with an ice vortex, inflicting Frostbite on enemies—and occasionally freezing them.</td>\r\n</tr>\r\n    <tr><td>Frost Bolt</td>\r\n<td>Shoots a frost bolt that knocks enemies back. (Hold down the button for more power.)</td>\r\n</tr>\r\n    <tr><td>Ice Eruption</td>\r\n<td>Launches a miniature avalanche to crush enemies.</td>\r\n</tr>\r\n    <tr><td>Ice Spikes</td>\r\n<td>Freezes the area around you, leaving it spiky and frosty.</td>\r\n</tr>\r\n    <tr><td>Icy BFG</td>\r\n<td>Aim and fire a ray of pure cold, shattering nearly everyone it touches. (Hold down the button to power up the ray.).</td>\r\n</tr>\r\n    <tr><td>Snowpocalypse</td>\r\n<td>Unleash a bonechilling cyclone straight ahead, picking up and damaging every enemy in its path.</td>\r\n</tr>\r\n    <tr><td>Winter is Coming</td>\r\n<td>Draws in enemies and freezes them a pillar of ice.</td>\r\n</tr>\r\n    <tr><td>Ice Shield</td>\r\n<td>Temporarily surround yourself with a shield made of ice.</td>\r\n</tr>\r\n    <tr><td>Snowmageddon</td>\r\n<td>Devastate a large area with an apocalyptic blast of sub-zero energy.</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n\r\n<h3>The Shadow Mage</h3>\r\n\r\n<p>Shadow mages unleash dark energy upon their enemies. They call forth shadows to fight for them and fire bullets of pure darkness. They are also the only gunmage class that can make melee attacks.</p>\r\n\r\n<table>\r\n    <tbody><tr><th>Attack</th>\r\n<th>The Kritikal Impact</th>\r\n</tr>\r\n    <tr><td>Shadow Vortex</td>\r\n<td>Surround yourself with whirling shadow blades, shredding nearby enemies.</td>\r\n</tr>\r\n    <tr><td>Hidden Strike</td>\r\n<td>Lay a trap to ensnare enemies.</td>\r\n</tr>\r\n    <tr><td>Shadowlunge</td>\r\n<td>Dash forward and strike a target.</td>\r\n</tr>\r\n    <tr><td>Shadowfist</td>\r\n<td>Summon a shadowy figure that lashes out at enemies in front of you, knocking then back.</td>\r\n</tr>\r\n    <tr><td>Dark Talons</td>\r\n<td>Summon a shadowy figure that slashes your enemies.</td>\r\n</tr>\r\n    <tr><td>Shadowhunters</td>\r\n<td>Fires ghost bullets that home in on targets—then ricochet to seek additional targets.</td>\r\n</tr>\r\n    <tr><td>Shadowbolt</td>\r\n<td>Unleash a torrent of dark force.</td>\r\n</tr>\r\n    <tr><td>Wraith Strike</td>\r\n<td>Separates your enemies from their shadows. Damage dealt to the shadows carries over to the original target.</td>\r\n</tr>\r\n    <tr><td>Shadow Mire</td>\r\n<td>Lays a trap that holds enemies in place.</td>\r\n</tr>\r\n    <tr><td>Specter</td>\r\n<td>Summon a massive shadow to strike your enemies, then imprison them in a spiky prison.</td>\r\n</tr>\r\n    <tr><td>Doppelganger</td>\r\n<td>Creates a shadowy double to fight alongside you.</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n\r\n<h3>Skill Modifiers: EX and Awakened</h3>\r\n\r\n<img class=\"left-image\" src=\"/assets/warrior-placeholder.jpg\" />\r\n\r\n<p>EX skills cast enhanced versions of your skills, but rely on EX energy to use. When your EX bar is full, press Tab to activate EX mode, then choose the skill you want to use. EX energy drains quickly, though, so make your choice fast.</p>\r\n\r\n<p>Awakened skills provide boosts and tweaks to your skills. You\'ll only have a limited number of points to spend on these, though, so improve the ones you use most.</p>'),(38,38,'en','2017-04-21 23:37:29','2017-04-21 23:37:29',''),(39,39,'en','2017-04-21 23:37:29','2017-04-21 23:37:29',''),(40,40,'en','2017-04-21 23:37:29','2017-04-21 23:37:29',''),(41,41,'en','2017-04-21 23:37:54','2017-04-21 23:37:54',''),(42,42,'en','2017-04-21 23:37:54','2017-04-21 23:37:54',''),(43,43,'en','2017-04-21 23:37:54','2017-04-21 23:37:54',''),(44,44,'en','2017-04-21 23:37:54','2017-04-21 23:37:54',''),(45,45,'en','2017-04-21 23:37:54','2017-04-21 23:37:54',''),(46,46,'en','2017-04-21 23:38:05','2017-04-21 23:38:05',''),(47,47,'en','2017-04-21 23:38:05','2017-04-21 23:38:05',''),(48,48,'en','2017-04-21 23:38:05','2017-04-21 23:38:05',''),(49,49,'en','2017-04-21 23:38:05','2017-04-21 23:38:05',''),(50,50,'en','2017-04-21 23:38:05','2017-04-21 23:38:05',''),(51,51,'en','2017-04-21 23:38:12','2017-04-24 23:13:27','<h2 class=\"logo-swap\">Kritika Online</h2>\r\n<h2 class=\"packs-swap\">Founder\'s Packs</h2>\r\n<img src=\"/assets/icons/store/group.png\" alt=\"kritika group\" />'),(52,52,'en','2017-04-21 23:38:12','2017-04-25 18:03:47','<div class=\"bundle invite\">\r\n                            <h2 class=\"bundle-title\">\r\n                                <span>Join the</span> Wait list\r\n                            </h2>\r\n                            <p>You can join the Kritika Online <br /><span class=\"yellow\">Beta Wait List</span> <br />for FREE!\r\n</p>\r\n                            <button type=\"button\" class=\"buy-bundle\" id=\"packageSignup\">Sign Up</button>\r\n                    </div>\r\n                    <div class=\"bundle\">\r\n                        <h2 class=\"bundle-title\">\r\n                            Into the dark <br /><span>Pack</span>\r\n                        </h2>\r\n                        <ul>\r\n                        <li class=\"access\"><span class=\"yellow\">Closed Beta</span> Instant Access! <br />+ <span class=\"yellow\">Open Beta</span> Head Start Access!</li>\r\n                        <li class=\"scroll\"><span class=\"yellow\">Founder\'s Title:</span>\r\n<br /> Advance Guard</li>\r\n                        <li class=\"emp-2\"><span class=\"yellow\">2,000 EMP</span>\r\n<br /> In-Game Currency</li>\r\n                        <li class=\"elite30\"><span class=\"yellow\">Elite Status Voucher</span>\r\n<br /> (Kritika, 30 Days)</li>\r\n                        </ul>\r\n                        <button type=\"button\" class=\"buy-bundle\" id=\"package3\">\r\n                            <div class=\"price-block offer\">\r\n                                <div class=\"sale\">$14.99</div>\r\n                                <div class=\"price\">$19.99</div>\r\n                            </div>\r\n                            Buy <span>Now!</span>\r\n                        </button>\r\n                    </div>\r\n                    <div class=\"bundle\">\r\n                        <h2 class=\"bundle-title\">\r\n                            Dark<br /> Companion <span>Pack</span>\r\n                        </h2>\r\n                        <ul>\r\n                        <li class=\"access\"><span class=\"yellow\">Closed Beta</span> Instant Access! <br />+ <span class=\"yellow\">Open Beta</span> Head Start Access!</li>\r\n                        <li class=\"pet\"><span class=\"yellow\">Dark Companion</span>\r\n<br /> Permananent Pet</li>\r\n                        <li class=\"glasses\"><span class=\"yellow\">Black Sunglasses</span> and <span class=\"yellow\">Leopard Sunglasses</span>\r\n</li>\r\n                        <li class=\"scroll\"><span class=\"yellow\">Founder\'s Title:</span>\r\n<br /> Advance Guard</li>\r\n                        <li class=\"emp-3\"><span class=\"yellow\">4,000 EMP</span>\r\n<br /> In-Game Currency</li>\r\n                        <li class=\"elite90\"><span class=\"yellow\">Elite Status Voucher</span>\r\n<br /> (Kritika, 90 Days)</li>\r\n                        </ul>\r\n                       <button type=\"button\" class=\"buy-bundle\" id=\"package3\">\r\n                            <div class=\"price-block offer\">\r\n                                <div class=\"sale\">$29.99</div>\r\n                                <div class=\"price\">$39.99</div>\r\n                            </div>\r\n                            Buy <span>Now!</span>\r\n                        </button>\r\n                    </div>\r\n                    <div class=\"bundle\">\r\n                        <h2 class=\"bundle-title\">\r\n                            Dark<br /> Guardians <span>Pack</span>\r\n                        </h2>\r\n                        <ul>\r\n                        <li class=\"access\"><span class=\"yellow\">Closed Beta</span> Instant Access! <br />+ <span class=\"yellow\">Open Beta</span> Head Start Access!</li>\r\n                        <li class=\"costumes\"></li>\r\n                        <li class=\"pet\"><span class=\"yellow\">Dark Companion</span>\r\n<br /> Permananent Pet</li>\r\n                        <li class=\"glasses\"><span class=\"yellow\">Black Sunglasses</span> and <span class=\"yellow\">Leopard Sunglasses</span>\r\n</li>\r\n                        <li class=\"scroll\"><span class=\"yellow\">Founder\'s Title:</span>\r\n<br /> Advance Guard</li>\r\n                        <li class=\"emp-4\"><span class=\"yellow\">10,000 EMP</span>\r\n<br /> In-Game Currency</li>\r\n                        <li class=\"elite180\"><span class=\"yellow\">Elite Status Voucher</span>\r\n<br /> (Kritika, 180 Days)</li>\r\n                        </ul>\r\n                        <button type=\"button\" class=\"buy-bundle\" id=\"package3\">\r\n                            <div class=\"price-block offer\">\r\n                                <div class=\"sale\">$74.99</div>\r\n                                <div class=\"price\">$99.99</div>\r\n                            </div>\r\n                            Buy <span>Now!</span>\r\n                        </button>\r\n                    </div>'),(53,53,'en','2017-04-21 23:38:12','2017-04-24 23:25:57','<div class=\"perks\">\r\n    <h1>About <span>The Perks</span>\r\n</h1>\r\n    <div id=\"perk-access\" class=\"perk\">\r\n        <div class=\"content\">\r\n            <h2><span>Closed Beta</span> Instant Access! + <span>Open Beta</span> Head Start Access!</h2>\r\n            <p>We explore the latest creamy developments in this special no-holds-barred lobster bisque showdown. Twelve complete, but only one chef will win our covetted Platinum Claw. Gentelmen, START YOUR LOBSTERS!</p>\r\n            <p>We explore the latest creamy developments in this special no-holds-barred lobster bisque showdown. Twelve complete, but only one chef will win our covetted Platinum Claw. Gentelmen, START YOUR LOBSTERS! We explore the latest creamy developments in this special no-holds-barred lobster bisque showdown.</p> \r\n        </div>\r\n    </div>\r\n    <div id=\"perk-title\" class=\"perk\">\r\n        <div class=\"content\">\r\n            <h2><span>Founder’s Title:</span> Advance Guard</h2>\r\n            <p>We explore the latest creamy developments in this special no-holds-barred lobster bisque showdown. Twelve complete, but only one chef will win our covetted Platinum Claw. Gentelmen, START YOUR LOBSTERS!</p>\r\n            <p>We explore the latest creamy developments in this special no-holds-barred lobster bisque showdown. Twelve complete, but only one chef will win our covetted Platinum Claw. Gentelmen, START YOUR LOBSTERS! We explore the latest creamy developments in this special no-holds-barred lobster bisque showdown.</p> \r\n        </div>\r\n    </div>\r\n    <div id=\"perk-emp\" class=\"perk\">\r\n        <div class=\"content\">\r\n            <h2><span>EMP</span> In-Game Currency</h2>\r\n            <p>We explore the latest creamy developments in this special no-holds-barred lobster bisque showdown. Twelve complete, but only one chef will win our covetted Platinum Claw. Gentelmen, START YOUR LOBSTERS!</p>\r\n            <p>We explore the latest creamy developments in this special no-holds-barred lobster bisque showdown. Twelve complete, but only one chef will win our covetted Platinum Claw. Gentelmen, START YOUR LOBSTERS! We explore the latest creamy developments in this special no-holds-barred lobster bisque showdown.</p> \r\n        </div>\r\n    </div>\r\n    <div id=\"perk-elite\" class=\"perk\">\r\n        <div class=\"content\">\r\n            <h2><span>Elite Status Vouchers</span>\r\n</h2>\r\n            <p>We explore the latest creamy developments in this special no-holds-barred lobster bisque showdown. Twelve complete, but only one chef will win our covetted Platinum Claw. Gentelmen, START YOUR LOBSTERS!</p>\r\n            <p>We explore the latest creamy developments in this special no-holds-barred lobster bisque showdown. Twelve complete, but only one chef will win our covetted Platinum Claw. Gentelmen, START YOUR LOBSTERS! We explore the latest creamy developments in this special no-holds-barred lobster bisque showdown.</p> \r\n        </div>\r\n    </div>\r\n    <div id=\"perk-glasses\" class=\"perk\">\r\n        <div class=\"content\">\r\n            <h2><span>Black Sunglasses</span> and <span>Leopard Sunglasses</span>\r\n</h2>\r\n            <p>We explore the latest creamy developments in this special no-holds-barred lobster bisque showdown. Twelve complete, but only one chef will win our covetted Platinum Claw. Gentelmen, START YOUR LOBSTERS!</p>\r\n            <p>We explore the latest creamy developments in this special no-holds-barred lobster bisque showdown. Twelve complete, but only one chef will win our covetted Platinum Claw. Gentelmen, START YOUR LOBSTERS! We explore the latest creamy developments in this special no-holds-barred lobster bisque showdown.</p> \r\n        </div>\r\n    </div>\r\n    <div id=\"perk-pet\" class=\"perk\">\r\n        <div class=\"content\">\r\n            <h2><span>Dark Companion</span> Permanent Pet</h2>\r\n            <p>We explore the latest creamy developments in this special no-holds-barred lobster bisque showdown. Twelve complete, but only one chef will win our covetted Platinum Claw. Gentelmen, START YOUR LOBSTERS!</p>\r\n            <p>We explore the latest creamy developments in this special no-holds-barred lobster bisque showdown. Twelve complete, but only one chef will win our covetted Platinum Claw. Gentelmen, START YOUR LOBSTERS! We explore the latest creamy developments in this special no-holds-barred lobster bisque showdown.</p> \r\n        </div>\r\n    </div>\r\n    <div id=\"perk-costumes\" class=\"perk\">\r\n        <div class=\"content\">\r\n            <h2><span>Dark Guardians</span> Permanent Costumes</h2>\r\n            <p>We explore the latest creamy developments in this special no-holds-barred lobster bisque showdown. Twelve complete, but only one chef will win our covetted Platinum Claw. Gentelmen, START YOUR LOBSTERS!</p>\r\n            <p>We explore the latest creamy developments in this special no-holds-barred lobster bisque showdown. Twelve complete, but only one chef will win our covetted Platinum Claw. Gentelmen, START YOUR LOBSTERS! We explore the latest creamy developments in this special no-holds-barred lobster bisque showdown.</p> \r\n        </div>\r\n    </div>\r\n</div>'),(54,54,'en','2017-04-21 23:38:12','2017-04-21 23:38:12',''),(55,55,'en','2017-04-21 23:38:12','2017-04-21 23:38:12',''),(56,56,'en','2017-04-21 23:38:21','2017-04-21 23:38:21',''),(57,57,'en','2017-04-21 23:38:21','2017-04-21 23:38:21',''),(58,58,'en','2017-04-21 23:38:21','2017-04-21 23:38:21',''),(59,59,'en','2017-04-21 23:38:21','2017-04-21 23:38:21',''),(60,60,'en','2017-04-21 23:38:21','2017-04-21 23:38:21',''),(61,61,'en','2017-04-24 17:03:15','2017-04-24 17:48:38','<div class=\"logo\">\r\n						Kritika Online\r\n					</div>\r\n					<div class=\"btn\">\r\n						<a href=\"/\">Get <span>Beta Access</span>\r\n</a>\r\n					</div>'),(62,62,'en','2017-04-24 17:03:15','2017-04-24 17:48:38','<div class=\"leftCol\">\r\n						<h2>Nonstop <span>Action!</span>\r\n</h2>\r\n						<p>Brawl with friends or rampage solo through a lavish 3D RPG world filled with hordes of enemies and grandiose cinematic displays.</p>\r\n						<p>Take on the bad guys with oversized blades, alchemical superguns, and dazzling acrobatics. There\'s no need for a lot of talk—you\'ll be too busy fighting enemies across dozens of Danger Zones in a fully realized, immersive arcade brawler!</p>\r\n					</div>\r\n					<div class=\"rightCol\">\r\n						<button type=\"button\" id=\"trailerKritika\" class=\"trailer\" data-url=\"https://www.youtube.com/embed/GwoFsacU4As\"></button>\r\n					</div>'),(63,63,'en','2017-04-24 17:03:15','2017-04-25 17:35:01','<div id=\"character-cards\" class=\"coverup\">\r\n					<div id=\"tile-nav\">\r\n						<div class=\"column-nav open\" id=\"reaper-nav\" data-open=\"char-reaper\"></div>\r\n						<div class=\"column-nav\" id=\"warrior-nav\" data-open=\"char-warrior\"></div>\r\n						<div class=\"column-nav\" id=\"gunmage-nav\" data-open=\"char-gunmage\"></div>\r\n						<div class=\"column-nav\" id=\"rogue-nav\" data-open=\"char-rogue\"></div>\r\n					</div>\r\n					<div id=\"card_wrapper\">\r\n						<div class=\"card open\" id=\"char-reaper\">\r\n							<div class=\"card_bg\"></div>\r\n							<div class=\"card_character\" data-top=\"-200px\" data-left=\"-130px\"></div>\r\n							<div class=\"card-sleeve\">\r\n								<div class=\"inner\">\r\n									<h6>The <span>Reaper</span>\r\n</h6>\r\n									<p>The cunning Reaper uses her scythe, chains, and blood to control enemies and unleash deadly destruction.</p>\r\n									<ul>\r\n										<li class=\"icon valkyrie\"><span>As the Valkyrie, switch between your melee hit and run Battle Stance and the ranged control of Chain Stance.</span>\r\n</li>\r\n										<li class=\"icon vamp\"><span>As the Vamp, drain blood from your enemies and use it to fuel deadly assaults.</span>\r\n</li>\r\n									</ul>\r\n								</div>\r\n							</div>\r\n						</div>\r\n						<div class=\"card\" id=\"char-warrior\">\r\n							<div class=\"card_bg\"></div>\r\n							<div class=\"card_character\" data-top=\"-370px\" data-left=\"-100px\"></div>\r\n							<div class=\"card-sleeve\">\r\n								<div class=\"inner\">\r\n									<h6>The <span>Warrior</span>\r\n</h6>\r\n									<p>The daring Warrior is a sword-wielding close-combat fighter. Bold, utough, and strong, the Warrior is a front-line powerhouse who can dispatch enemies with ease. His massive sword deals a tremendous amount of damage, making short work of even bosses.</p>\r\n									<ul>\r\n										<li class=\"icon berseker\"><span>As the Berserker, channel your inner rage into wild, spectacular onslaughts.</span>\r\n</li>\r\n										<li class=\"icon firelord\"><span>As the Fire Lord, draw flame energy into your fist to boost the power of your attacks.</span>\r\n</li>\r\n										<li class=\"icon doomblade\"><span>As the Doom Blade, harness the curse of your soul-stealing blade.</span>\r\n</li>\r\n									</ul>\r\n								</div>\r\n							</div>\r\n						</div>\r\n						<div class=\"card\" id=\"char-gunmage\">\r\n							<div class=\"card_bg\"></div>\r\n							<div class=\"card_character\" data-top=\"-60px\" data-left=\"-230px\"></div>\r\n							<div class=\"card-sleeve\">\r\n								<div class=\"inner\">\r\n									<h6>The <span>Gunmage</span>\r\n</h6>\r\n									<p>The cocky Gunmage uses his prowess with guns to focus elemental magic. Clever and powerful, he keeps his enemies off balance, weak, and at a distance.</p>\r\n									<ul>\r\n										<li class=\"icon frost\"><span>As the Frost Mage, harness the cold to blast your enemies and freeze them in place.</span>\r\n</li>\r\n										<li class=\"icon shadow\"><span>As the Shadow Mage, unleash shadows and dark energy from other dimensions.</span>\r\n</li>\r\n										<li class=\"icon warp\"><span>As the Warp Mage, command time and space to trap, confuse, and confound your foes.</span>\r\n</li>\r\n									</ul>\r\n								</div>\r\n							</div>\r\n						</div>\r\n						<div class=\"card\" id=\"char-rogue\">\r\n							<div class=\"card_bg\"></div>\r\n							<div class=\"card_character\" data-top=\"-350px\" data-left=\"0px\"></div>\r\n							<div class=\"card-sleeve\">\r\n								<div class=\"inner\">\r\n									<h6>The <span>Rogue</span>\r\n</h6>\r\n									<p>The cheeky rogue uses cat-like acrobatics to hit hard, slice, scratch, or shock her opponents. Always the opportunist, she excels at back attacks, misdirection, and outright elemental destruction.</p>\r\n									<ul>\r\n										<li class=\"icon catspaw\"><span>As the Catspaw, tumble to their weak spot and slice your opponenet with your claw like blades.</span>\r\n</li>\r\n										<li class=\"icon assassin\"><span>As the Assassin, excel at the hit and run, often disappearing before your foe hits the ground.</span>\r\n</li>\r\n										<li class=\"icon wolf\"><span>As the Wolf Guardian, command a deadly spirit animal and elemental lightning.</span>\r\n</li>\r\n									</ul>\r\n								</div>\r\n							</div>\r\n						</div>\r\n					</div>\r\n				</div>'),(64,64,'en','2017-04-24 17:03:15','2017-04-24 17:48:38','<h2><span>Fast</span> Progression</h2>\r\n					<p>Danger Zones designed for quick play sessions propel you into the action, without lengthy world travel. And each one has a super-sized boss you\'ll just love to beat on!</p>\r\n					<p>The action is fast, and the enemies are furious. Things have gotten a lot weirder since Abelard and his Dominion Army rose to power in Kirenos. </p>\r\n					<p>It\'s gonna take some heroes to stop him, and only the best of the best should answer the call!</p>'),(65,65,'en','2017-04-24 17:03:15','2017-04-25 18:05:26','<h2 class=\"logo-swap\">Kritika Online</h2>\r\n<h2 class=\"packs-swap\">Founder\'s Packs</h2>\r\n<img src=\"/assets/icons/store/group.png\" alt=\"kritika group\" />\r\n<div class=\"bundle invite\">\r\n                            <h2 class=\"bundle-title\">\r\n                                <span>Join the</span> Wait list\r\n                            </h2>\r\n                            <p>You can join the Kritika Online <br /><span class=\"yellow\">Beta Wait List</span> <br />for FREE!\r\n</p>\r\n                            <button type=\"button\" class=\"buy-bundle\" id=\"packageSignup\">Sign Up</button>\r\n                    </div>\r\n                    <div class=\"bundle\">\r\n                        <h2 class=\"bundle-title\">\r\n                            Into the dark <br /><span>Pack</span>\r\n                        </h2>\r\n                        <ul>\r\n                        <li class=\"access\"><span class=\"yellow\">Closed Beta</span> Instant Access! <br />+ <span class=\"yellow\">Open Beta</span> Head Start Access!</li>\r\n                        <li class=\"scroll\"><span class=\"yellow\">Founder\'s Title:</span>\r\n<br /> Advance Guard</li>\r\n                        <li class=\"emp-2\"><span class=\"yellow\">2,000 EMP</span>\r\n<br /> In-Game Currency</li>\r\n                        <li class=\"elite30\"><span class=\"yellow\">Elite Status Voucher</span>\r\n<br /> (Kritika, 30 Days)</li>\r\n                        </ul>\r\n                        <button type=\"button\" class=\"buy-bundle\" id=\"package3\">\r\n                            <div class=\"price-block offer\">\r\n                                <div class=\"sale\">$14.99</div>\r\n                                <div class=\"price\">$19.99</div>\r\n                            </div>\r\n                            Buy <span>Now!</span>\r\n                        </button>\r\n                    </div>\r\n                    <div class=\"bundle\">\r\n                        <h2 class=\"bundle-title\">\r\n                            Dark<br /> Companion <span>Pack</span>\r\n                        </h2>\r\n                        <ul>\r\n                        <li class=\"access\"><span class=\"yellow\">Closed Beta</span> Instant Access! <br />+ <span class=\"yellow\">Open Beta</span> Head Start Access!</li>\r\n                        <li class=\"pet\"><span class=\"yellow\">Dark Companion</span>\r\n<br /> Permananent Pet</li>\r\n                        <li class=\"glasses\"><span class=\"yellow\">Black Sunglasses</span> and <span class=\"yellow\">Leopard Sunglasses</span>\r\n</li>\r\n                        <li class=\"scroll\"><span class=\"yellow\">Founder\'s Title:</span>\r\n<br /> Advance Guard</li>\r\n                        <li class=\"emp-3\"><span class=\"yellow\">4,000 EMP</span>\r\n<br /> In-Game Currency</li>\r\n                        <li class=\"elite90\"><span class=\"yellow\">Elite Status Voucher</span>\r\n<br /> (Kritika, 90 Days)</li>\r\n                        </ul>\r\n                       <button type=\"button\" class=\"buy-bundle\" id=\"package3\">\r\n                            <div class=\"price-block offer\">\r\n                                <div class=\"sale\">$29.99</div>\r\n                                <div class=\"price\">$39.99</div>\r\n                            </div>\r\n                            Buy <span>Now!</span>\r\n                        </button>\r\n                    </div>\r\n                    <div class=\"bundle\">\r\n                        <h2 class=\"bundle-title\">\r\n                            Dark<br /> Guardians <span>Pack</span>\r\n                        </h2>\r\n                        <ul>\r\n                        <li class=\"access\"><span class=\"yellow\">Closed Beta</span> Instant Access! <br />+ <span class=\"yellow\">Open Beta</span> Head Start Access!</li>\r\n                        <li class=\"costumes\"></li>\r\n                        <li class=\"pet\"><span class=\"yellow\">Dark Companion</span>\r\n<br /> Permananent Pet</li>\r\n                        <li class=\"glasses\"><span class=\"yellow\">Black Sunglasses</span> and <span class=\"yellow\">Leopard Sunglasses</span>\r\n</li>\r\n                        <li class=\"scroll\"><span class=\"yellow\">Founder\'s Title:</span>\r\n<br /> Advance Guard</li>\r\n                        <li class=\"emp-4\"><span class=\"yellow\">10,000 EMP</span>\r\n<br /> In-Game Currency</li>\r\n                        <li class=\"elite180\"><span class=\"yellow\">Elite Status Voucher</span>\r\n<br /> (Kritika, 180 Days)</li>\r\n                        </ul>\r\n                        <button type=\"button\" class=\"buy-bundle\" id=\"package3\">\r\n                            <div class=\"price-block offer\">\r\n                                <div class=\"sale\">$74.99</div>\r\n                                <div class=\"price\">$99.99</div>\r\n                            </div>\r\n                            Buy <span>Now!</span>\r\n                        </button>\r\n                    </div>\r\n<div class=\"btn moreinfo\"><a href=\"/store\">More Info</a>\r\n</div>'),(66,66,'en','2017-04-24 19:16:45','2017-04-24 19:16:45',''),(67,67,'en','2017-04-24 19:16:45','2017-04-24 19:16:45',''),(68,68,'en','2017-04-24 19:16:45','2017-04-24 19:16:45',''),(69,69,'en','2017-04-24 19:16:45','2017-04-24 19:16:45',''),(70,70,'en','2017-04-24 19:16:45','2017-04-24 19:16:45',''),(71,71,'en','2017-04-24 19:17:20','2017-04-24 19:17:20',''),(72,72,'en','2017-04-24 19:17:20','2017-04-24 19:17:20',''),(73,73,'en','2017-04-24 19:17:20','2017-04-24 19:17:20',''),(74,74,'en','2017-04-24 19:17:20','2017-04-24 19:21:59','<h1>Privacy Policy</h1>\r\n<p>PLEASE READ THE FOLLOWING LEGAL DOCUMENTS CAREFULLY.</p>\r\n<p>En Masse Entertainment, Inc. (\"En Masse\", \"we,\" or \"our\") respects your privacy and is committed to protecting the Personal Information that you may provide us while using our site located at <a href=\"http://www.enmasse.com/en\" title=\"http://www.enmasse.com\">http://www.enmasse.com</a>&#160;(the \"Site\") and the services and features offered through the Site. Your use of the Site is subject to your agreement to the terms of this privacy policy (\"Privacy Policy\") and the Terms of Service.</p>\r\n<p>YOUR ACCEPTANCE OF THIS PRIVACY POLICY IS A NECESSARY CONDITION FOR USING THE SITE, INCLUDING, WITHOUT LIMITATION, THE SERVICES EN MASSE PERFORMS ON BEHALF OF ITS AFFILIATES. BY USING THE SITE, YOU AGREE TO BE BOUND BY THIS PRIVACY POLICY\'S TERMS AND CONDITIONS.&#160;</p>\r\n<div>\r\n<h3>1. Personal Information</h3>\r\n<p>As used in this Privacy Policy, \"Personal Information\" is information that would allow someone to identify or contact you, including, for example, your full name, address, telephone number, or email address. Personal Information does not include aggregated information that, by itself, does not permit the identification of individual persons (like statistics about how many persons visited the Site last month, or how many visitors are male and how many are female).  En Masse does not collect any Personal Information from you unless you provide it to us voluntarily. If you refuse to divulge your Personal Information when requested, you may not be able to access certain areas of the Site.&#160;</p>\r\n<h3>2. Site Registration</h3>\r\n<p>In order for you to register for an account En Masse may require you to provide us with certain information including your name, birth date, e-mail address, and mailing address. We do not require Personal Information to obtain access to the Site; however, you will not be able to access areas that require registration.</p>\r\n<h3>3. Non-Personal Information</h3>\r\n<p>In addition to account registration data, En Masse will automatically collect certain non-Personal Information about your use of the Site. We might collect, among other things, information concerning the type of Internet browser or computer operating system you are using, the domain name of your Internet service provider, your browsing behavior through the Site, and the web site or advertisement that was linked to or from the Site when you visited. To do this, we may use cookies and other technology (see below). Your visits to the Site, and information provided through these technologies, will be anonymous unless you provide us with Personal Information or have provided such information in the past. This information is used to help improve the Site, analyze trends, and administer the Site.</p>\r\n<h3>4. Cookie and Related Technologies</h3>\r\n<p>En Masse uses cookies and other technologies to collect demographic information, personalize your experience on the Site and monitor advertisements and other activities. Cookies are small files downloaded to your computer (if your browser is enabled to accept cookies) to track movements within web sites. We may link cookie information to Personal Information. We use cookies and other technology to customize your experience within the Site. Personal Information collected through the use of these technologies will be handled according to this Privacy Policy.</p>\r\n<p>Most Internet browsers will allow you to erase cookies from your computer hard drive, block acceptance of cookies, or receive a warning before a cookie is stored. You should refer to your browser instructions or \"Help\" screen to learn more about how to manage cookies. Please note, however, that if you block cookies, some portions of the Site may not function properly.</p>\r\n<p>We do not control cookies in third party ads, and you are encouraged to check the privacy policies of advertisers and/or ad services to learn about their use of cookies and other technology. The ads appearing on the Site may be delivered to you by third-party advertising companies. These companies may use information about your visits to this and other web sites in order to provide advertisements on the Site and other sites about goods and services that may be of interest to you.</p>\r\n<p>We also maintain log files which contain Internet Protocol (\"IP\") addresses. An IP address is a numeric address that is assigned to your computer by your Internet Service Provider. We use log files to monitor traffic on the Site, to report information to our advertisers and to troubleshoot technical problems. In the event of user abuse of the Site, we may block certain IP addresses. IP addresses may be used to personally identify you in order to enforce our Terms of Service and any applicable end user license agreement.</p>\r\n<h3>5. Statistical and Usage Data</h3>\r\n<p>When you use the Site, we may retrieve information about your hardware system and how our services are used, including your IP address. We use this information to enable you to use the services offered through the Site over the Internet. We also use this information to better understand the behavior and preferences of our customers, so that we can improve our products and services.</p>\r\n<h3>6. How Personal Information is Used</h3>\r\n<p>The Personal Information collected from you will be used to operate the Site and to provide the products or services or carry out the transactions you have requested or authorized.</p>\r\n<p>In support of these uses, En Masse may use Personal Information to provide you with more effective service, to improve the Site and any related En Masse products or services, and to make the Site easier to use by eliminating the need for you to repeatedly enter the same information. In order to offer you a more consistent experience in your interactions with En Masse, information collected by the Site may be combined with information collected by En Masse from other sources.</p>\r\n<p>We may use your Personal Information to provide you with information about the product or service that you have purchased or inquired about.  Additionally, we may send you information about other En Masse products and services, and/or share information with En Masse partners so they may send you information about their products and services.</p>\r\n<p>We may merge Site-visitation data with demographic information, and we may use this information to provide more relevant content.  We may combine Site-visitation data with your Personal Information in order to provide you with personalized content. <br />En Masse may hire other companies to provide products or services on our behalf, and we may provide such companies with Personal Information to help them perform their duties. </p>\r\n<p>En Masse may disclose Personal Information if required to do so by law or in the good faith belief that such action is necessary to (a) conform to the edicts of the law or comply with legal process served on En Masse; (b) protect and defend the rights or property of En Masse or its affiliates; or (c) act in urgent circumstances to protect the personal safety of En Masse employees or agents, users of En Masse products or services, or members of the public.</p>\r\n<p>Personal information collected on the Site may be stored and processed in the State of Washington or any other state or country in which En Masse or its affiliates or agents maintain facilities, and by using the Site you consent to any such transfer of information to another state or country.</p>\r\n<p>You will be deemed to have consented to the disclosure to, and use by, a subsequent owner or operator of the Site, of any Personal Information contained in our database for such site, if En Masse or one of its companies assigns all of its rights and obligations regarding the use of your Personal Information at the time of a bankruptcy, merger, acquisition, sale of all or substantially all of En Masse\'s assets to a subsequent owner or operator, or similar event.</p>\r\n<p>Please do not use your real name or the real name of another person when selecting a username. Please note that your username will be available to the Internet\'s general public while you participate in some services, like message boards or forums, so you should exercise discretion when using these services. We are not responsible for protecting such information that you may disclose to third parties through our services.</p>\r\n<h3>7. Children Under the Age of 13</h3>\r\n<p>Because the Site is not directed to children under the age of 13, we prohibit registration to persons under age 13. If you are under the age of 13, you may not create an account on the Site. We will not knowingly collect, maintain, or disclose any Personal Information from children under the age of 13.</p>\r\n<h3>8. Children Between the Ages of 13 and 18</h3>\r\n<p>In order to protect the privacy interests of younger Internet users, En Masse does not allow children under the age of 18 to use our services without the consent of their parents. En Masse complies with the Children\'s Online Privacy Protection Act and all other applicable laws and regulations concerning children and the Internet. We do not disclose any Personal Information about children under 18 years of age who have registered on the Site to third parties, or share or disclose Personal Information other than as set forth in this Privacy Policy; provided however, that in the event of a merger, acquisition, bankruptcy, or similar transaction, management of our customer information may be transferred to our successor or assign.</p>\r\n<h3>9. Links and Third Party Services</h3>\r\n<p>If you click on a link to a third party site, including on an advertisement, you will leave the Site and go to the site you selected. Because we cannot control the activities of third parties, we cannot accept responsibility for any use of your Personal Information by such third parties, and we cannot guarantee that they will adhere to the same privacy and security practices as En Masse. We encourage you to review the privacy policies of any other service provider from whom you request services. If you visit a third party website that is linked to the Site, you should consult that site\'s privacy policy before providing any Personal Information.</p>\r\n<h3>10. Accessing or Changing Personal Information</h3>\r\n<p>To review and update your Personal Information stored with En Masse, please access your account.&#160;</p>\r\n<h3>11. Security of Personal Information</h3>\r\n<p>En Masse follows generally accepted industry standards to protect Personal Information submitted to us, both during transmission and once we receive it. When you enter sensitive information (such as a credit card number) on the Site, we encrypt that information using secure socket layer (SSL) technology. However, no method of transmission over the Internet, or method of electronic storage, is completely secure. Therefore, while we strive to use commercially acceptable means to protect your Personal Information, we cannot guarantee its absolute security.</p>\r\n<h3>12. Information for People Outside the United States</h3>\r\n<p>By accepting this Privacy Policy, you confirm your command and knowledge of English is sufficient to understand the terms and conditions set forth herein. For persons in European Union countries, as used herein, terms such as \"Personal Information\" refer to \"personal data\" as defined by the Directive 95/46/EC of the European Parliament and of the Council of 24 October 1995 on the protection of individuals with regard to the processing of personal data and on the free movement of such data (\"Directive\"). We will not collect any personal data from you unless you provide it voluntarily. By using the Site, you agree that we may transfer your personal data outside the European Union in connection with the purposes stated in this Privacy Policy. Your personal data may be transferred to the United States, and/or other non-EU jurisdictions, as applicable.</p>\r\n<h3>13. Other Agreements That Govern Your Use of The Site</h3>\r\n<p>In addition to this Privacy Policy, your rights and obligations concerning the use of the Site are governed by our Terms of Service, any end user license agreement, any other supplemental agreements, and other applicable policies, guidelines, and requirements. When you sign up to use the Site, please review each such agreement carefully, as you must agree to be bound by each such agreement before you may use the service.</p>\r\n<h3>14. Notice of Changes to the Privacy Policy</h3>\r\n<p>By using the Site, you signify your assent to En Masse\'s Privacy Policy. If you do not agree to this Privacy Policy, please do not use the Site. We reserve the right to modify this Privacy Policy at any time, so please review it frequently. If we make material changes to this policy, we will also revise the \"last updated\" date at the top of this Privacy Policy, and may attempt to notify you by email, pop-up screen, or by means of a notice somewhere else on the Site. Your continued use of the Site will signify your acceptance of the changes to our Privacy Policy.</p>\r\n</div>'),(75,75,'en','2017-04-24 19:17:20','2017-04-24 19:17:20',''),(76,76,'en','2017-04-24 19:17:35','2017-04-24 19:17:35',''),(77,77,'en','2017-04-24 19:17:35','2017-04-24 19:17:35',''),(78,78,'en','2017-04-24 19:17:35','2017-04-24 19:17:35',''),(79,79,'en','2017-04-24 19:17:35','2017-04-24 19:22:40','<h1>Terms of Service</h1>\r\n\r\n<p>This Terms of Service governs your use of our website located at <a href=\"http://www.enmasse.com\">http://www.enmasse.com</a>, and all software, products, games (the “Games”), features and services made available, displayed or offered by or through such website (collectively, the “Service”). The Service is operated by En Masse Entertainment, Inc., its parents, subsidiaries and affiliates (collectively, “En Masse”, “we,” or “our”). The Service Privacy Policy (<a href=\"http://www.enmasse.com/privacy-policy\">http://www.enmasse.com/privacy-policy</a>), end user license agreement, any supplemental terms provided to you by En Masse are an integral part of this Terms of Service and are incorporated herein by reference.</p>\r\n\r\n<h3>1. Ownership and Grant of Use</h3>\r\n\r\n<p>The entire contents of the Service, including without limitation all information, material, trademarks, software, video, photographs, graphics, text, music and sound, are owned or licensed by En Masse under applicable laws. En Masse owns rights in the selection, coordination, arrangement and enhancement of such content.</p>\r\n\r\n<p>You may not transmit, participate in the transfer or sale, create derivative works from, modify, publish, or in any way exploit, any of the content contained in the Service (including, without limitation, any content that our Service enables you to download) without the express written permission of En Masse and any other applicable owner. In the event of any permitted copying, redistribution or publication of any content, no changes in or deletion of any author attribution, trademark, or copyright notice may be made. The downloading of content from the Service is allowed by you only for your personal use.</p>\r\n\r\n<p>You acknowledge that En Masse and/or third-party content providers remain the owners of all content contained in the Service, and that you do not acquire any ownership rights by downloading, using or paying fees to acquire licenses to use any content.</p>\r\n\r\n<p>As long as you comply with this Terms of Service and it has not been terminated, En Masse grants you a personal, non-commercial, non-exclusive, non-transferable, limited right to enter, use, perform and display our Service and its contents.</p>\r\n\r\n<h3>2. User Content</h3>\r\n\r\n<p>The Service incorporates certain communication features such as forums, message boards, chat, messenger-type features, and email that may be provided to registered and unregistered users (collectively, “Game Communication Features”). You acknowledge that by using Game Communication Features, you may be exposed to messages, information, data, text, software, graphic files, or other materials, whether in written, verbal, electronic, digital, machine-readable or other form (“User Content”) that you might find objectionable.</p>\r\n\r\n<p>EN MASSE DOES NOT TOTALLY CONTROL USER CONTENT AND DOES NOT GUARANTEE ITS ACCURACY, INTEGRITY OR QUALITY. You understand that any User Content sent through or appearing on the Game Communication Features is the sole responsibility of those persons transmitting such User Content. This means that you, and not En Masse, are entirely responsible for all User Content that you transmit. Under no circumstances will En Masse be liable for any errors or omissions in any User Content or for any loss or damages of any kind incurred as a result of the access to, downloading, viewing, listening, use of or inability to use any User Content sent through or appearing on any Game Communication Features.</p>\r\n\r\n<p>En Masse has no obligation to monitor or supervise the Game Communication Features and/or User Content, and expressly disclaims any representation that we will monitor or supervise such features and/or User Content. However, we expressly reserve the right, but not the obligation, in our sole discretion to monitor, screen, edit, block or remove any User Content, in whole or in part, sent through or appearing on any Game Communication Feature and you have no expectation of privacy in any content in any of the Game Communication Features. Without limiting the foregoing, En Masse and its designees shall have the right to block or remove, in whole or in part, any User Content that is in violation of this Terms of Service, is illegal, infringing or otherwise offensive or objectionable. Accordingly, you acknowledge that the Game Communication Features are forums for public and not private communications. YOU AGREE TO INDEMNIFY AND HOLD EN MASSE AND ITS DESIGNEES HARMLESS FROM ANY CLAIM OR DEMAND, INCLUDING REASONABLE ATTORNEYS’ FEES, MADE BY ANY THIRD PARTY DUE TO OR ARISING OUT OF YOUR VIOLATION OF THESE TERMS AND CONDITIONS OR YOUR VIOLATION OF ANY RIGHTS OF ANOTHER.</p>\r\n\r\n<p>Any and all User Content submitted to En Masse shall be deemed, and shall remain, the property of En Masse from the moment such User Content is created. En Masse shall exclusively own all now known or hereafter existing copyrights and all other intellectual property rights to all User Content of every kind and nature, in perpetuity throughout the world. To the extent that any of the above may be void or unenforceable, you agree that any and all User Content is hereby irrevocably assigned to En Masse, together with all intellectual property rights therein. To the extent any of the User Content is not assignable, by submitting User Content to En Masse, you agree that En Masse shall be irrevocably entitled, directly or indirectly throughout the world and in perpetuity, to modify, adapt, use, reproduce, license, publish, broadcast, perform, sell, translate, create derivative works from and distribute any User Content for any purpose whatsoever, commercial or otherwise, in any medium now known or hereafter devised, without compensation or credit to the provider or author of the User Content. You also give up any claim that any use by En Masse of any User Content violates any of your rights, including but not limited to moral rights, rights of privacy, rights to publicity, proprietary or other rights, and/or rights to credit for the material or ideas set forth therein.</p>\r\n\r\n<h3>3. Eligibility</h3>\r\n\r\n<p>If you are between the ages of thirteen (13) and eighteen (18), your parent or guardian must complete the registration process, in which case such parent or guardian will take full responsibility for all obligations under this Terms of Service. You represent that you are at least eighteen (18) years of age and are either accepting this Terms of Service on behalf of yourself or on behalf of your minor child. You may not transfer, sell, or share your Account with anyone, unless you are a parent or guardian, in which case you may permit your minor child to use the Account. You are liable for all activities conducted through the Account.</p>\r\n\r\n<p>The Children’s Online Privacy Protection Act, administered by the Federal Trade Commission, imposes rules regarding the collection of personal information from children. The Service is not directed to children under the age of thirteen (13). If you are under the age of thirteen (13) you may not create an Account and must not provide any personal information to En Masse.</p>\r\n\r\n<h3>4. Establishing an Account and Access to the Service</h3>\r\n\r\n<p>A. The Service is an on-line or mobile game service that must be played over the Internet or mobile network as provided by En Masse, and you are wholly responsible for acquiring and paying for your own Internet or mobile network access along with all necessary equipment, servicing, repair or correction incurred in maintaining the use of  the Service and the related services.</p>\r\n\r\n<p>B. A Game account (“Account”) may be required to access certain features of Game, including the Game Communications Features. If you have questions about Account registration, please visit: Creating and Managing Your En Masse Account.</p>\r\n\r\n<p>To create an Account, you must provide your name, date of birth, mailing address and valid email address. You must provide truthful and accurate information. Accounts are available only to adults.</p>\r\n\r\n<p>During the registration process, you may be required to provide your login ID (your verifiable email address) and a password (collectively referred to as “Login Information”). You may not share the Account or the Login Information with anyone other than as expressly set forth herein. You are responsible for maintaining the confidentiality of the Login Information, and you will be responsible for all uses of the Login Information, whether or not authorized by you. In the event that you become aware of or reasonably suspect any breach of security, including without limitation any loss, theft, or unauthorized disclosure of the Login Information, you must immediately notify En Masse by emailing to us. You are solely responsible for all activity on your Account. You should not reveal your Account password to others. En Masse will not ask you to reveal your password or initiate contact with you asking for answers to your password security questions.</p>\r\n\r\n<p>C. Username. In addition to your Login Information, you may be required to select a unique username for use with the Game Communication Features. Your username can be seen by others.</p>\r\n\r\n<p>Therefore, if En Masse finds a username to be offensive or improper, it may, in its sole and absolute discretion, change or ask you to change the username, block such user registration, remove the username from all aspects of the Game and Service, and/or suspend or terminate your Account. In particular, you may not use the name of another person, or a name which infringes a third party’s trademark, copyright, or other proprietary right. You may not use a name which may mislead others to believe you to be an employee of En Masse, or which En Masse deems at its sole discretion to be vulgar or otherwise offensive. En Masse reserves the right, but not the obligation, in its sole and absolute discretion, to delete or alter any username, terminate or suspend your Account, or terminate any license granted herein, for any reason whatsoever.</p>\r\n\r\n<p>Your Username may be deactivated if you do not use it for a long period of time after the date that it was created and En Masse may remove and delete your Username at our sole discretion. We will use reasonable efforts to notify you by email before we delete your Username. If you advise us within five days of the notice that you want to keep your Username active, we will not delete it. If you do not so notify us, your Username will be permanently deleted, along with your User account records, ranks and service information.</p>\r\n\r\n<p>NOTWITHSTANDING ANYTHING TO THE CONTRARY HEREIN, YOU ACKNOWLEDGE AND AGREE THAT YOU SHALL HAVE NO OWNERSHIP OR OTHER PROPERTY INTEREST IN THE ACCOUNT, AND YOU FURTHER ACKNOWLEDGE AND AGREE THAT ALL RIGHTS IN AND TO THE ACCOUNT ARE AND SHALL FOREVER BE OWNED BY AND INURE TO THE BENEFIT OF EN MASSE. En Masse does not recognize the transfer of Accounts or any items incorporated into or part of the Game or Service, including without limitation any characters, game items, EMPs or any other content or information therein (“Contents”). You may not purchase, sell, gift, trade, or offer to purchase, sell, gift or trade, any Account or any Contents incorporated into or part of the Game or Service, and any such attempt shall be null and void.</p>\r\n\r\n<h3>5. Paid Services</h3>\r\n\r\n<p>A. You may need to pay fees to access and acquire licenses to use certain game items or participate in game activities. You must have an Account and pay applicable fees by using online currency (“EMP”) to use such game items and participate in these activities. For more information about subscription and other fees for particular services, visit the En Masse Store.</p>\r\n\r\n<p>In order to obtain EMPs, you may be required to provide us or a third-party payment service provider designated by En Masse with your credit card information and other information related to any type of payment and transaction. If your use of En Masse’s service, purchase of subscription or game items is subject to use or sales tax or fees charged by third party service providers, En Masse or the third-party payment service provider may charge for any such taxes and fees. As the account holder, you are responsible for all charges incurred, including applicable taxes and all purchases made via your Account.</p>\r\n\r\n<p>If you leave a balance of EMP unused for a long period of time, we may process your EMP balance in accordance with our legal obligations, including by submitting funds associated with your EMP balance to the appropriate governing body where required by law or charge inactivity fees in accordance with applicable rules and regulations.</p>\r\n\r\n<p>YOU UNDERSTAND AND AGREE THAT ANY APPLICABLE FEES AND OTHER CHARGES ARE PAYABLE IN ADVANCE AND ARE NOT REFUNDABLE IN WHOLE OR IN PART.</p>\r\n\r\n<p>B. Certain game items have an expiration date, while others have no expiration date. Each game item that you acquire will be included in your Account until the earlier of that game item’s expiration date, if applicable or your Account’s expiration or termination date, or such date when the service ends.</p>\r\n\r\n<p>C. En Masse reserves the right to change our fees or billing methods at any time. If any change is unacceptable to you, you may terminate your Account but En Masse will not refund any fees that may have accrued to your Account before your termination of your Account and En Masse will not prorate fees for any subscription or game items, which has not been expired before the termination.</p>\r\n\r\n<p>REGARDLESS OF THE CONSIDERATION OFFERED OR PAID IN EXCHANGE FOR GAME ITEMS, YOU DO NOT HAVE ANY OWNERSHIP RIGHTS IN THE GAME ITEMS.</p>\r\n\r\n<h3>6. Consent to Use of Data and Public Display</h3>\r\n\r\n<p>For purposes that En Masse deems necessary, including but not limited to facilitating technical protection measures or providing software updates, content, support and other services to you, you agree that En Masse or its agents may collect, use, store and transmit technical and related information that identifies your machine (including an Internet protocol address and machine ID), operating system, application software, and peripheral hardware. You agree En Masse and its agents may also use this information in the aggregate, in a form which does not personally identify you, to improve its products and services and may share anonymous aggregate data with third parties.</p>\r\n\r\n<p>You agree that En Masse and its agents may collect, use, store, transmit, and publicly display statistical data regarding the game play (including scores, rankings and achievements) or identify content that is created and shared by you and other users. Data that personally identifies you may be collected, used, stored and transmitted in accordance with the privacy policy published at <a href=\"http://www.enmasse.com/privacy-policy\">http://www.enmasse.com/privacy-policy</a>.</p>\r\n\r\n<h3>7. Service Interruptions and Changes to the Service</h3>\r\n\r\n<p>En Masse reserves the right to interrupt all or any aspect of the Service from time to time on a regularly scheduled basis or otherwise with or without prior notice in order to perform maintenance. You agree that En Masse will not be liable for any interruption of the Service, delay or failure to perform resulting from any causes whatsoever. You acknowledge that the Service may be interrupted for reasons beyond the control of En Masse, and En Masse cannot guarantee that you will be able to access the Service or your Account whenever you may wish to do so. En Masse has the right at any time for any reason or no reason to change and/or eliminate any aspect of the Service as it sees fit in its sole discretion.</p>\r\n\r\n<h3>8. Links to Third-Party Sites</h3>\r\n\r\n<p>En Masse may include hyperlinks to web sites operated by third parties including payment service providers and other content providers. Those sites may collect data or solicit personal information from you. En Masse does not control such web sites, and is not responsible for their content, privacy policies, or for the collection use or disclosure of any information those sites may collect.</p>\r\n\r\n<h3>9. Patches and Updates</h3>\r\n\r\n<p>From time to time in its sole discretion, En Masse may deploy or provide patches, updates and modifications to the Service that must be installed for you to continue to play Game. En Masse may update the Game remotely including without limitation the Game Client residing on your machine, without your knowledge and you hereby grant En Masse your consent to deploy and supply such patches, updates and modifications.</p>\r\n\r\n<h3>10. Termination and Suspension</h3>\r\n\r\n<p>You or En Masse may terminate this Terms of Service and your Account at any time. You may terminate this Terms of Service at any time by terminating all your registered. En Masse can terminate this Terms of Service by asking you to stop using the Service, and, at En Masse’s sole and absolute discretion, by preventing your access to the Service and/or your Account. Upon termination of this Terms of Service, you will have no further rights to use the Service.</p>\r\n\r\n<p>Your only right and remedy with respect to any dissatisfaction with the Service or any content therein is to terminate this Terms of Service and your Account and to cease using any services available through the Service, including Game Communication Features. You acknowledge and agree that you are not entitled to any refund for any amounts that you paid before the termination. En Masse reserves the right to collect fees, surcharges or costs incurred before you terminate your Account or a subscription. You are also responsible for any amounts owed to third-party vendors or content providers before your termination. Any delinquent or unpaid fees and other unresolved issues with En Masse’s service must be settled before you establish a new Account.</p>\r\n\r\n<p>Without limiting the foregoing, En Masse shall have the right to terminate this Terms of Service with you, effective immediately, and/or terminate or temporarily suspend your access to your Account and/or all or any part of the Service, without notice, in the event of any conduct by you which En Masse, in its sole and absolute discretion, considers to be unacceptable, or for conduct that En Masse believes is a violation of the terms and conditions contained herein or any other policies of En Masse, or for other conduct which En Masse believes, in its sole and absolute discretion, is harmful to En Masse, other Service users, or third parties. En Masse reserves the right to deny any account registration and to deny access to the Service to any individual.</p>\r\n\r\n<p>The provisions of Sections 1, 2, 7, 11, 12 and 14 shall survive any termination of this Terms of Service.</p>\r\n\r\n<h3>11. Changes to Terms of Service</h3>\r\n\r\n<p>En Masse reserves the right, at its sole and absolute discretion, to change, modify, add to, supplement or delete any of the terms and conditions of this Terms of Service at any time, including without limitation access policies, the availability of any feature of the Service, hours of availability, content, data, software or equipment needed to access the Service, effective with or without prior notice; provided, however, that En Masse intends to disclose material changes (as determined in En Masse’s sole and absolute discretion) to you through any of one or a combination of: a patch process, or by email, postal mail, website posting, or pop-up screen. If you cannot comply with changes to this Terms of Service, or such changes are unacceptable to you, you must not use or access the Service and your Account. Continuing to access or use the Service following any revision to this Terms of Service constitutes your complete and irrevocable acceptance of any and all such changes. En Masse may change, modify, suspend, or discontinue any aspect of the Service at any time. En Masse may also impose limits on certain features or restrict your access to parts or all of the Service without notice or liability. If you do not agree to any new terms, or to any of the terms in this Terms of Service, your only remedy is to not access or use the Service and to cancel your Account.</p>\r\n\r\n<h3>12. Notice to California Residents</h3>\r\n\r\n<p>Under California Civil Code Section 1789.3, users from California are entitled to the following specific consumer rights notice: The Complaint Assistance Unit of the Division of Consumer Services of the California Department of Consumer Affairs may be contacted in writing at 400 R Street, Suite 1080, Sacramento, California 95814, or by telephone at (916) 445-1254 or (800) 952-5210.</p>\r\n\r\n<h3>13. Miscellaneous</h3>\r\n\r\n<p>If any provision of this Terms of Service shall be unlawful, void, or for any reason unenforceable, then that provision shall be deemed severable from this Terms of Service and shall not affect the validity and enforceability of any remaining provisions. This Terms of Service is the complete and exclusive statement of the agreement between you and En Masse concerning the Service, and this Terms of Service supersedes any prior or contemporaneous agreement, either oral or written, and any other communications with regard thereto between you and En Masse; provided, however that this Terms of Service is in addition to, and does not replace or supplant the  Privacy Policy, any applicable end user license agreement, and any supplemental agreement. This Terms of Service may only be modified as set forth herein. The section headings used herein are for reference only and shall not be read to have any legal effect.</p>\r\n\r\n<p>YOU HEREBY ACKNOWLEDGE THAT YOU HAVE READ AND UNDERSTAND THE END USER LICENSE AGREEMENT AND TERMS OF SERVICE AND AGREE THAT YOUR USE OF THE SERVICE IS BOUND BY THE TERMS AND CONDITIONS ABOVE.</p>\r\n'),(80,80,'en','2017-04-24 19:17:35','2017-04-24 19:17:35',''),(81,81,'en','2017-04-24 19:17:48','2017-04-24 19:17:48',''),(82,82,'en','2017-04-24 19:17:48','2017-04-24 19:17:48',''),(83,83,'en','2017-04-24 19:17:48','2017-04-24 19:17:48',''),(84,84,'en','2017-04-24 19:17:48','2017-04-24 19:23:17','<h1>Rules of Conduct</h1>\r\n\r\n<p>TL;DR—Play nice with others; don’t be an ass!</p>\r\n\r\n<p>For those of you who actually take the time to read this, the rules of conduct are guidelines that we ask you to follow while playing any of our games or participating on our websites. It’s safe to say that these may change from time to time, so it’s worth checking back every once in a while.</p>\r\n\r\n<p>Ignorance of the rules does not excuse violation of them. Violations may result in temporary suspensions or permanent destruction of your account.</p>\r\n\r\n<ol>\r\n	<li>Do not attack someone personally, including their race, gender, religion, nationality, ethics, sexual preference, or personal beliefs. Keep it clean.</li>\r\n	<li>Avoid using copyrighted and trademarked material.</li>\r\n	<li>Do not pretend to be any employee affiliated with us unless you want to be banned.</li>\r\n	<li>Don’t harass, stalk, or purposely do things to make someone else feel uncomfortable.</li>\r\n	<li>Do not post or use graphic sexual, grotesque, or violent language or images. There are enough websites out there for this. We don’t need another one.</li>\r\n	<li>Child predation or pornography = BAN! And possibly the authorities get involved, too.</li>\r\n	<li>Do not share personal information about yourself or other individuals.</li>\r\n	<li>Masked profanity: We all know you can use l33t 5p34k to mask bad stuff. Don’t do it.</li>\r\n	<li>Real money solicitations: As if online games need more spamming for gold. This also includes power-leveling services, selling characters, items, or anything else. These services lead to account theft, credit card fraud, and stolen identities. It also sucks.</li>\r\n	<li>Advertising your own or someone else’s business or ventures is not acceptable behavior.</li>\r\n	<li>Scamming: This is like stealing. Don’t do it.</li>\r\n	<li>Spamming: We get it. You have some awesome armor for sale. Saying it every five seconds is not the way to sell it.</li>\r\n	<li>Cheating: Do not use third party programs, macros, client side hacks, or other things that give you an unfair advantage in the game. Just because others haven’t gotten caught (yet) doesn’t mean you should do it.</li>\r\n	<li>Gambling: Running or participating in a gambling-for-gold operation within the game is a no-no.</li>\r\n	<li>Hacking: This goes without saying, but don’t hack us or someone else. Don’t distribute or promote material related to this. It’s not cool.</li>\r\n	<li>Trolling: You don’t want to be “that person.”</li>\r\n	<li>Spamming support: We want your questions, and we want to answer them—but sending us 100 emails about the same subject before we get the chance to answer the first one only slows us down more. It also increases the response time for other players.</li>\r\n	<li>Game exploits: Let us know about these instead of exploiting them. If you use any game’s mechanics in any way the GMs deem unsportsmanlike or that deviates from the spirit of the game, the GM staff will not only make frownie faces at you, but possibly pursue disciplinary action.</li>\r\n	<li>Private servers: Do not participate, promote, or set one up.</li>\r\n	<li>CAPS LOCK: Avoid excessive use of the caps lock. It can get annoying.</li>\r\n	<li>Don’t include hidden links to websites.</li>\r\n	<li>…</li>\r\n	<li>Rule 22 said “Don’t make empty forum posts.”</li>\r\n	<li>Do not request, arrange, or offer pirated materials, illegal activities, or illegal drugs.</li>\r\n	<li>Do not use a foreign language in an effort to avoid getting caught for breaking these rules.</li>\r\n	<li>Our employees will use their discretion to interpret if any action warrants moderation, whether it is mentioned here or not. We also have a magic genie that grants us the ability to make more rules, but we’d rather use those powers to make cool stuff for you.</li>\r\n</ol>'),(85,85,'en','2017-04-24 19:17:48','2017-04-24 19:17:48','');
/*!40000 ALTER TABLE `refinery_page_part_translations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `refinery_page_parts`
--

DROP TABLE IF EXISTS `refinery_page_parts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `refinery_page_parts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `refinery_page_id` int(11) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `body` text,
  `position` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_refinery_page_parts_on_id` (`id`),
  KEY `index_refinery_page_parts_on_refinery_page_id` (`refinery_page_id`)
) ENGINE=InnoDB AUTO_INCREMENT=86 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `refinery_page_parts`
--

LOCK TABLES `refinery_page_parts` WRITE;
/*!40000 ALTER TABLE `refinery_page_parts` DISABLE KEYS */;
INSERT INTO `refinery_page_parts` VALUES (1,1,'body',NULL,0,'2017-04-18 21:52:40','2017-04-18 21:52:40','Body'),(2,1,'side_body',NULL,1,'2017-04-18 21:52:40','2017-04-18 21:52:40','Side Body'),(3,2,'body',NULL,0,'2017-04-18 21:52:41','2017-04-18 21:52:41','Body'),(6,4,'article_header',NULL,0,'2017-04-18 21:52:43','2017-04-18 21:53:56','Article Header'),(7,4,'body',NULL,1,'2017-04-18 21:52:43','2017-04-18 21:53:56','Body'),(8,4,'side_body',NULL,2,'2017-04-18 21:52:44','2017-04-18 21:53:56','Side Body'),(9,4,'wide_body',NULL,3,'2017-04-18 21:52:44','2017-04-18 21:53:56','Wide Body'),(10,4,'article_footer',NULL,4,'2017-04-18 21:52:45','2017-04-18 21:53:56','Article Footer'),(11,5,'article_header',NULL,0,'2017-04-21 19:50:29','2017-04-24 21:54:00','Article Header'),(12,5,'body',NULL,1,'2017-04-21 19:50:29','2017-04-25 16:31:34','Body'),(13,5,'side_body',NULL,2,'2017-04-21 19:50:29','2017-04-21 19:50:29','Side Body'),(14,5,'wide_body',NULL,3,'2017-04-21 19:50:29','2017-04-21 19:50:29','Wide Body'),(15,5,'article_footer',NULL,4,'2017-04-21 19:50:29','2017-04-21 19:50:29','Article Footer'),(16,6,'article_header',NULL,0,'2017-04-21 19:52:42','2017-04-24 20:20:28','Article Header'),(17,6,'body',NULL,1,'2017-04-21 19:52:42','2017-04-25 16:26:02','Body'),(18,6,'side_body',NULL,2,'2017-04-21 19:52:42','2017-04-21 19:52:42','Side Body'),(19,6,'wide_body',NULL,3,'2017-04-21 19:52:42','2017-04-21 19:52:42','Wide Body'),(20,6,'article_footer',NULL,4,'2017-04-21 19:52:42','2017-04-21 19:52:42','Article Footer'),(21,7,'article_header',NULL,0,'2017-04-21 20:59:50','2017-04-21 20:59:50','Article Header'),(22,7,'body',NULL,1,'2017-04-21 20:59:50','2017-04-21 20:59:50','Body'),(23,7,'side_body',NULL,2,'2017-04-21 20:59:50','2017-04-21 20:59:50','Side Body'),(24,7,'wide_body',NULL,3,'2017-04-21 20:59:50','2017-04-21 20:59:50','Wide Body'),(25,7,'article_footer',NULL,4,'2017-04-21 20:59:51','2017-04-21 20:59:51','Article Footer'),(26,8,'article_header',NULL,0,'2017-04-21 21:20:33','2017-04-24 21:40:27','Article Header'),(27,8,'body',NULL,1,'2017-04-21 21:20:33','2017-04-25 16:26:32','Body'),(28,8,'side_body',NULL,2,'2017-04-21 21:20:33','2017-04-21 21:20:33','Side Body'),(29,8,'wide_body',NULL,3,'2017-04-21 21:20:33','2017-04-21 21:20:33','Wide Body'),(30,8,'article_footer',NULL,4,'2017-04-21 21:20:33','2017-04-21 21:20:33','Article Footer'),(31,9,'article_header',NULL,0,'2017-04-21 23:37:18','2017-04-24 21:40:57','Article Header'),(32,9,'body',NULL,1,'2017-04-21 23:37:18','2017-04-25 16:27:55','Body'),(33,9,'side_body',NULL,2,'2017-04-21 23:37:18','2017-04-21 23:37:18','Side Body'),(34,9,'wide_body',NULL,3,'2017-04-21 23:37:18','2017-04-21 23:37:18','Wide Body'),(35,9,'article_footer',NULL,4,'2017-04-21 23:37:18','2017-04-21 23:37:18','Article Footer'),(36,10,'article_header',NULL,0,'2017-04-21 23:37:29','2017-04-24 21:41:24','Article Header'),(37,10,'body',NULL,1,'2017-04-21 23:37:29','2017-04-25 16:28:36','Body'),(38,10,'side_body',NULL,2,'2017-04-21 23:37:29','2017-04-21 23:37:29','Side Body'),(39,10,'wide_body',NULL,3,'2017-04-21 23:37:29','2017-04-21 23:37:29','Wide Body'),(40,10,'article_footer',NULL,4,'2017-04-21 23:37:29','2017-04-21 23:37:29','Article Footer'),(41,11,'article_header',NULL,0,'2017-04-21 23:37:54','2017-04-21 23:37:54','Article Header'),(42,11,'body',NULL,1,'2017-04-21 23:37:54','2017-04-21 23:37:54','Body'),(43,11,'side_body',NULL,2,'2017-04-21 23:37:54','2017-04-21 23:37:54','Side Body'),(44,11,'wide_body',NULL,3,'2017-04-21 23:37:54','2017-04-21 23:37:54','Wide Body'),(45,11,'article_footer',NULL,4,'2017-04-21 23:37:54','2017-04-21 23:37:54','Article Footer'),(46,12,'article_header',NULL,0,'2017-04-21 23:38:05','2017-04-21 23:38:05','Article Header'),(47,12,'body',NULL,1,'2017-04-21 23:38:05','2017-04-21 23:38:05','Body'),(48,12,'side_body',NULL,2,'2017-04-21 23:38:05','2017-04-21 23:38:05','Side Body'),(49,12,'wide_body',NULL,3,'2017-04-21 23:38:05','2017-04-21 23:38:05','Wide Body'),(50,12,'article_footer',NULL,4,'2017-04-21 23:38:05','2017-04-21 23:38:05','Article Footer'),(51,13,'article_header',NULL,0,'2017-04-21 23:38:12','2017-04-24 23:13:27','Article Header'),(52,13,'body',NULL,1,'2017-04-21 23:38:12','2017-04-25 18:03:47','Body'),(53,13,'side_body',NULL,2,'2017-04-21 23:38:12','2017-04-24 23:25:57','Side Body'),(54,13,'wide_body',NULL,3,'2017-04-21 23:38:12','2017-04-21 23:38:12','Wide Body'),(55,13,'article_footer',NULL,4,'2017-04-21 23:38:12','2017-04-21 23:38:12','Article Footer'),(56,14,'article_header',NULL,0,'2017-04-21 23:38:21','2017-04-21 23:38:21','Article Header'),(57,14,'body',NULL,1,'2017-04-21 23:38:21','2017-04-21 23:38:21','Body'),(58,14,'side_body',NULL,2,'2017-04-21 23:38:21','2017-04-21 23:38:21','Side Body'),(59,14,'wide_body',NULL,3,'2017-04-21 23:38:21','2017-04-21 23:38:21','Wide Body'),(60,14,'article_footer',NULL,4,'2017-04-21 23:38:21','2017-04-21 23:38:21','Article Footer'),(61,15,'article_header',NULL,0,'2017-04-24 17:03:15','2017-04-24 17:48:38','Article Header'),(62,15,'body',NULL,1,'2017-04-24 17:03:15','2017-04-24 17:48:38','Body'),(63,15,'side_body',NULL,2,'2017-04-24 17:03:15','2017-04-25 17:35:01','Side Body'),(64,15,'wide_body',NULL,3,'2017-04-24 17:03:15','2017-04-24 17:48:38','Wide Body'),(65,15,'article_footer',NULL,4,'2017-04-24 17:03:15','2017-04-25 18:05:26','Article Footer'),(66,16,'article_header',NULL,0,'2017-04-24 19:16:45','2017-04-24 19:16:45','Article Header'),(67,16,'body',NULL,1,'2017-04-24 19:16:45','2017-04-24 19:16:45','Body'),(68,16,'side_body',NULL,2,'2017-04-24 19:16:45','2017-04-24 19:16:45','Side Body'),(69,16,'wide_body',NULL,3,'2017-04-24 19:16:45','2017-04-24 19:16:45','Wide Body'),(70,16,'article_footer',NULL,4,'2017-04-24 19:16:45','2017-04-24 19:16:45','Article Footer'),(71,17,'article_header',NULL,0,'2017-04-24 19:17:20','2017-04-24 19:17:20','Article Header'),(72,17,'body',NULL,1,'2017-04-24 19:17:20','2017-04-24 19:17:20','Body'),(73,17,'side_body',NULL,2,'2017-04-24 19:17:20','2017-04-24 19:17:20','Side Body'),(74,17,'wide_body',NULL,3,'2017-04-24 19:17:20','2017-04-24 19:21:59','Wide Body'),(75,17,'article_footer',NULL,4,'2017-04-24 19:17:20','2017-04-24 19:17:20','Article Footer'),(76,18,'article_header',NULL,0,'2017-04-24 19:17:35','2017-04-24 19:17:35','Article Header'),(77,18,'body',NULL,1,'2017-04-24 19:17:35','2017-04-24 19:17:35','Body'),(78,18,'side_body',NULL,2,'2017-04-24 19:17:35','2017-04-24 19:17:35','Side Body'),(79,18,'wide_body',NULL,3,'2017-04-24 19:17:35','2017-04-24 19:22:40','Wide Body'),(80,18,'article_footer',NULL,4,'2017-04-24 19:17:35','2017-04-24 19:17:35','Article Footer'),(81,19,'article_header',NULL,0,'2017-04-24 19:17:48','2017-04-24 19:17:48','Article Header'),(82,19,'body',NULL,1,'2017-04-24 19:17:48','2017-04-24 19:17:48','Body'),(83,19,'side_body',NULL,2,'2017-04-24 19:17:48','2017-04-24 19:17:48','Side Body'),(84,19,'wide_body',NULL,3,'2017-04-24 19:17:48','2017-04-24 19:23:17','Wide Body'),(85,19,'article_footer',NULL,4,'2017-04-24 19:17:48','2017-04-24 19:17:48','Article Footer');
/*!40000 ALTER TABLE `refinery_page_parts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `refinery_page_translations`
--

DROP TABLE IF EXISTS `refinery_page_translations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `refinery_page_translations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `refinery_page_id` int(11) NOT NULL,
  `locale` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `custom_slug` varchar(255) DEFAULT NULL,
  `menu_title` varchar(255) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_refinery_page_translations_on_refinery_page_id` (`refinery_page_id`),
  KEY `index_refinery_page_translations_on_locale` (`locale`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `refinery_page_translations`
--

LOCK TABLES `refinery_page_translations` WRITE;
/*!40000 ALTER TABLE `refinery_page_translations` DISABLE KEYS */;
INSERT INTO `refinery_page_translations` VALUES (1,1,'en','2017-04-18 21:52:39','2017-04-24 17:42:16','Home','','','home'),(2,2,'en','2017-04-18 21:52:41','2017-04-18 21:52:41','Page not found',NULL,NULL,'page-not-found'),(4,4,'en','2017-04-18 21:52:43','2017-04-18 21:53:56','News','','','news'),(5,5,'en','2017-04-21 19:50:29','2017-04-21 19:50:29','Guides','','','guides'),(6,6,'en','2017-04-21 19:52:42','2017-04-21 19:52:42','Warrior','','','warrior'),(7,7,'en','2017-04-21 20:59:50','2017-04-21 20:59:50','Classes','','','classes'),(8,8,'en','2017-04-21 21:20:33','2017-04-21 21:20:33','Rogue','','','rogue'),(9,9,'en','2017-04-21 23:37:18','2017-04-21 23:37:18','Reaper','','','reaper'),(10,10,'en','2017-04-21 23:37:29','2017-04-21 23:37:29','Gunmage','','','gunmage'),(11,11,'en','2017-04-21 23:37:54','2017-04-21 23:37:54','Community','','','community'),(12,12,'en','2017-04-21 23:38:05','2017-04-21 23:38:05','Media','','','media'),(13,13,'en','2017-04-21 23:38:12','2017-04-21 23:38:12','Store','','','store'),(14,14,'en','2017-04-21 23:38:21','2017-04-21 23:38:21','Support','','','support'),(15,15,'en','2017-04-24 17:03:15','2017-04-24 17:16:34','About','','','about'),(16,16,'en','2017-04-24 19:16:45','2017-04-24 19:16:45','Legal','','','legal'),(17,17,'en','2017-04-24 19:17:20','2017-04-24 19:17:20','Privacy Policy','','','privacy-policy'),(18,18,'en','2017-04-24 19:17:35','2017-04-24 19:17:35','Terms of Service','','','terms-of-service'),(19,19,'en','2017-04-24 19:17:48','2017-04-24 19:17:48','Rules of Conduct','','','rules-of-conduct');
/*!40000 ALTER TABLE `refinery_page_translations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `refinery_pages`
--

DROP TABLE IF EXISTS `refinery_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `refinery_pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT NULL,
  `path` varchar(255) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `custom_slug` varchar(255) DEFAULT NULL,
  `show_in_menu` tinyint(1) DEFAULT '1',
  `link_url` varchar(255) DEFAULT NULL,
  `menu_match` varchar(255) DEFAULT NULL,
  `deletable` tinyint(1) DEFAULT '1',
  `draft` tinyint(1) DEFAULT '0',
  `skip_to_first_child` tinyint(1) DEFAULT '0',
  `lft` int(11) DEFAULT NULL,
  `rgt` int(11) DEFAULT NULL,
  `depth` int(11) DEFAULT NULL,
  `view_template` varchar(255) DEFAULT NULL,
  `layout_template` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_refinery_pages_on_depth` (`depth`),
  KEY `index_refinery_pages_on_id` (`id`),
  KEY `index_refinery_pages_on_lft` (`lft`),
  KEY `index_refinery_pages_on_parent_id` (`parent_id`),
  KEY `index_refinery_pages_on_rgt` (`rgt`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `refinery_pages`
--

LOCK TABLES `refinery_pages` WRITE;
/*!40000 ALTER TABLE `refinery_pages` DISABLE KEYS */;
INSERT INTO `refinery_pages` VALUES (1,NULL,NULL,NULL,NULL,0,'/','^/$',0,0,0,1,4,0,'home','application','2017-04-18 21:52:39','2017-04-24 17:42:16'),(2,1,NULL,NULL,NULL,0,NULL,'^/404$',0,0,0,2,3,1,NULL,NULL,'2017-04-18 21:52:41','2017-04-18 21:52:41'),(4,NULL,NULL,NULL,NULL,1,'/news','^/news?(/|/.+?|)$',0,0,0,19,20,0,'show',NULL,'2017-04-18 21:52:43','2017-04-24 17:47:24'),(5,NULL,NULL,NULL,NULL,1,'',NULL,1,0,0,7,18,0,'show','application','2017-04-21 19:50:29','2017-04-24 21:54:00'),(6,7,NULL,NULL,NULL,1,'',NULL,1,0,0,9,10,2,'show','application','2017-04-21 19:52:42','2017-04-24 20:20:28'),(7,5,NULL,NULL,NULL,1,'',NULL,1,0,0,8,17,1,'show','guides','2017-04-21 20:59:50','2017-04-24 17:47:24'),(8,7,NULL,NULL,NULL,1,'',NULL,1,0,0,11,12,2,'show','application','2017-04-21 21:20:33','2017-04-24 21:40:27'),(9,7,NULL,NULL,NULL,1,'',NULL,1,0,0,13,14,2,'show','application','2017-04-21 23:37:18','2017-04-24 21:40:57'),(10,7,NULL,NULL,NULL,1,'',NULL,1,0,0,15,16,2,'show','application','2017-04-21 23:37:29','2017-04-24 21:41:24'),(11,NULL,NULL,NULL,NULL,1,'',NULL,1,0,0,21,22,0,'show','application','2017-04-21 23:37:54','2017-04-24 17:47:24'),(12,NULL,NULL,NULL,NULL,1,'',NULL,1,0,0,23,24,0,'show','application','2017-04-21 23:38:04','2017-04-24 17:47:24'),(13,NULL,NULL,NULL,NULL,1,'',NULL,1,0,0,25,26,0,'show','application','2017-04-21 23:38:12','2017-04-24 17:47:24'),(14,NULL,NULL,NULL,NULL,1,'',NULL,1,0,0,27,28,0,'show','application','2017-04-21 23:38:21','2017-04-24 17:47:24'),(15,NULL,NULL,NULL,NULL,1,'',NULL,1,0,0,5,6,0,'show','application','2017-04-24 17:03:15','2017-04-24 17:47:24'),(16,NULL,NULL,NULL,NULL,0,'',NULL,1,0,0,29,36,0,'show','application','2017-04-24 19:16:45','2017-04-24 19:17:49'),(17,16,NULL,NULL,NULL,1,'',NULL,1,0,0,30,31,1,'show','application','2017-04-24 19:17:20','2017-04-24 19:17:20'),(18,16,NULL,NULL,NULL,1,'',NULL,1,0,0,32,33,1,'show','application','2017-04-24 19:17:35','2017-04-24 19:17:36'),(19,16,NULL,NULL,NULL,1,'',NULL,1,0,0,34,35,1,'show','application','2017-04-24 19:17:48','2017-04-24 19:17:49');
/*!40000 ALTER TABLE `refinery_pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `refinery_resource_translations`
--

DROP TABLE IF EXISTS `refinery_resource_translations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `refinery_resource_translations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `refinery_resource_id` int(11) NOT NULL,
  `locale` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `resource_title` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_refinery_resource_translations_on_refinery_resource_id` (`refinery_resource_id`),
  KEY `index_refinery_resource_translations_on_locale` (`locale`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `refinery_resource_translations`
--

LOCK TABLES `refinery_resource_translations` WRITE;
/*!40000 ALTER TABLE `refinery_resource_translations` DISABLE KEYS */;
/*!40000 ALTER TABLE `refinery_resource_translations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `refinery_resources`
--

DROP TABLE IF EXISTS `refinery_resources`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `refinery_resources` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `file_mime_type` varchar(255) DEFAULT NULL,
  `file_name` varchar(255) DEFAULT NULL,
  `file_size` int(11) DEFAULT NULL,
  `file_uid` varchar(255) DEFAULT NULL,
  `file_ext` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `refinery_resources`
--

LOCK TABLES `refinery_resources` WRITE;
/*!40000 ALTER TABLE `refinery_resources` DISABLE KEYS */;
/*!40000 ALTER TABLE `refinery_resources` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `refinery_settings`
--

DROP TABLE IF EXISTS `refinery_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `refinery_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `value` text,
  `destroyable` tinyint(1) DEFAULT '1',
  `scoping` varchar(255) DEFAULT NULL,
  `restricted` tinyint(1) DEFAULT '0',
  `form_value_type` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_refinery_settings_on_name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `refinery_settings`
--

LOCK TABLES `refinery_settings` WRITE;
/*!40000 ALTER TABLE `refinery_settings` DISABLE KEYS */;
INSERT INTO `refinery_settings` VALUES (1,'comments_allowed','--- \'true\'\n',1,'blog',0,'text_area','2017-04-18 21:53:23','2017-04-18 21:53:23','comments_allowed',NULL),(2,'comment_moderation','--- \'true\'\n',1,'blog',0,'text_area','2017-04-18 21:53:23','2017-04-18 21:53:23','comment_moderation',NULL),(3,'teasers_enabled','--- \'true\'\n',1,'blog',0,'text_area','2017-04-18 21:53:24','2017-04-18 21:53:24','teasers_enabled',NULL);
/*!40000 ALTER TABLE `refinery_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schema_migrations`
--

DROP TABLE IF EXISTS `schema_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schema_migrations` (
  `version` varchar(255) NOT NULL,
  UNIQUE KEY `unique_schema_migrations` (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schema_migrations`
--

LOCK TABLES `schema_migrations` WRITE;
/*!40000 ALTER TABLE `schema_migrations` DISABLE KEYS */;
INSERT INTO `schema_migrations` VALUES ('20170105192639'),('20170105192640'),('20170105192641'),('20170105192642'),('20170105192643'),('20170105192644'),('20170105192645'),('20170105192646'),('20170105192647'),('20170105192648'),('20170105192649'),('20170105192650'),('20170105192651'),('20170105192652'),('20170105192653'),('20170105192654'),('20170105192655'),('20170404155955'),('20170404155956'),('20170404155957'),('20170404160557'),('20170404160558'),('20170404160559'),('20170404160560'),('20170404160561'),('20170404160562'),('20170404160563'),('20170404160564'),('20170404160565'),('20170404160566'),('20170404160567'),('20170404160568'),('20170404160569'),('20170404160570'),('20170404160571'),('20170414191328');
/*!40000 ALTER TABLE `schema_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `seo_meta`
--

DROP TABLE IF EXISTS `seo_meta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `seo_meta` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `seo_meta_id` int(11) DEFAULT NULL,
  `seo_meta_type` varchar(255) DEFAULT NULL,
  `browser_title` varchar(255) DEFAULT NULL,
  `meta_description` text,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `index_seo_meta_on_id` (`id`),
  KEY `id_type_index_on_seo_meta` (`seo_meta_id`,`seo_meta_type`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `seo_meta`
--

LOCK TABLES `seo_meta` WRITE;
/*!40000 ALTER TABLE `seo_meta` DISABLE KEYS */;
INSERT INTO `seo_meta` VALUES (1,1,'Refinery::Page::Translation','','','2017-04-18 21:52:39','2017-04-24 17:42:16'),(2,2,'Refinery::Page::Translation',NULL,NULL,'2017-04-18 21:52:41','2017-04-18 21:52:41'),(3,3,'Refinery::Page::Translation','','','2017-04-18 21:52:41','2017-04-21 19:41:21'),(4,4,'Refinery::Page::Translation','','','2017-04-18 21:52:43','2017-04-18 21:53:56'),(5,1,'Refinery::Blog::Post::Translation','','','2017-04-19 18:07:11','2017-04-19 18:07:11'),(6,1,'Refinery::Blog::Post',NULL,NULL,'2017-04-19 18:07:11','2017-04-19 18:07:11'),(7,5,'Refinery::Page::Translation','','','2017-04-21 19:50:29','2017-04-21 19:50:29'),(8,6,'Refinery::Page::Translation','','','2017-04-21 19:52:42','2017-04-21 19:52:42'),(9,7,'Refinery::Page::Translation','','','2017-04-21 20:59:50','2017-04-21 20:59:50'),(10,8,'Refinery::Page::Translation','','','2017-04-21 21:20:33','2017-04-21 21:20:33'),(11,9,'Refinery::Page::Translation','','','2017-04-21 23:37:18','2017-04-21 23:37:18'),(12,10,'Refinery::Page::Translation','','','2017-04-21 23:37:29','2017-04-21 23:37:29'),(13,11,'Refinery::Page::Translation','','','2017-04-21 23:37:54','2017-04-21 23:37:54'),(14,12,'Refinery::Page::Translation','','','2017-04-21 23:38:05','2017-04-21 23:38:05'),(15,13,'Refinery::Page::Translation','','','2017-04-21 23:38:12','2017-04-21 23:38:12'),(16,14,'Refinery::Page::Translation','','','2017-04-21 23:38:21','2017-04-21 23:38:21'),(17,15,'Refinery::Page::Translation','','','2017-04-24 17:03:15','2017-04-24 17:03:15'),(18,16,'Refinery::Page::Translation','','','2017-04-24 19:16:45','2017-04-24 19:16:45'),(19,17,'Refinery::Page::Translation','','','2017-04-24 19:17:20','2017-04-24 19:17:20'),(20,18,'Refinery::Page::Translation','','','2017-04-24 19:17:35','2017-04-24 19:17:35'),(21,19,'Refinery::Page::Translation','','','2017-04-24 19:17:48','2017-04-24 19:17:48'),(22,2,'Refinery::Blog::Post::Translation','','','2017-04-24 19:31:20','2017-04-24 19:31:20'),(23,2,'Refinery::Blog::Post',NULL,NULL,'2017-04-24 19:31:21','2017-04-24 19:31:21');
/*!40000 ALTER TABLE `seo_meta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `taggings`
--

DROP TABLE IF EXISTS `taggings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `taggings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tag_id` int(11) DEFAULT NULL,
  `taggable_id` int(11) DEFAULT NULL,
  `taggable_type` varchar(255) DEFAULT NULL,
  `tagger_id` int(11) DEFAULT NULL,
  `tagger_type` varchar(255) DEFAULT NULL,
  `context` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `taggings_idx` (`tag_id`,`taggable_id`,`taggable_type`,`context`,`tagger_id`,`tagger_type`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `taggings`
--

LOCK TABLES `taggings` WRITE;
/*!40000 ALTER TABLE `taggings` DISABLE KEYS */;
/*!40000 ALTER TABLE `taggings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `taggings_count` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_tags_on_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-04-25 18:32:06
